# Laza E-commerce Mobile App

## Project Overview
A simplified e-commerce mobile application built with Flutter and Firebase, featuring product browsing, cart management, and user authentication.

## Features
- 🔐 Email/Password Authentication with Firebase
- 🛍️ Product Browsing from Platzi Fake Store API
- ❤️ Add/Remove Favorites
- 🛒 Shopping Cart with Checkout
- 📱 Responsive Design for iOS & Android

## Tech Stack
- **Framework**: Flutter 3.0+
- **Backend**: Firebase (Auth & Firestore)
- **API**: Platzi Fake Store API
- **Testing**: Appium for E2E tests

## Prerequisites
- Flutter SDK 3.0 or higher
- Dart SDK 2.19 or higher
- Android Studio / Xcode
- Firebase Account
- Appium (for testing)

## Installation

### 1. Clone Repository
```bash
git clone https://github.com/yourusername/laza-ecommerce.git
cd laza-ecommerce