# Firebase Setup Guide for Laza E-commerce App

## Step 1: Create Firebase Project
1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Create a project"
3. Enter project name: `laza-ecommerce`
4. Enable Google Analytics (optional)
5. Click "Create project"

## Step 2: Register Your App
### Android Setup:
1. Click Android icon in project overview
2. Enter package name: `com.example.laza_ecommerce`
3. Enter app nickname: `Laza Ecommerce`
4. Click "Register app"
5. Download `google-services.json`
6. Place the file in `android/app/` directory

### iOS Setup:
1. Click iOS icon in project overview
2. Enter bundle ID: `com.example.lazaEcommerce`
3. Enter app nickname: `Laza Ecommerce iOS`
4. Click "Register app"
5. Download `GoogleService-Info.plist`
6. Place the file in `ios/Runner/` directory

## Step 3: Enable Authentication
1. In Firebase Console, go to "Authentication"
2. Click "Get started"
3. Go to "Sign-in method" tab
4. Enable "Email/Password" provider

## Step 4: Configure Firestore
1. Go to "Firestore Database"
2. Click "Create database"
3. Start in test mode (for development)
4. Choose location closest to your users
5. Click "Enable"

## Step 5: Update Firebase Rules
1. Go to "Firestore Database" → "Rules" tab
2. Replace existing rules with rules from `firestore.rules` file

## Step 6: Add Firebase Configuration
Update `lib/firebase_options.dart` with your actual API keys:
1. Go to Project Settings → General
2. Copy your app's configuration
3. Replace placeholders in `firebase_options.dart`

## Step 7: Install Firebase CLI (Optional)
```bash
npm install -g firebase-tools
firebase login
firebase init