package com.example.laza_ecommerce

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
