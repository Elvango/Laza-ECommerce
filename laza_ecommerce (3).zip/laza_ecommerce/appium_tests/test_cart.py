from appium import webdriver
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# Configuration
desired_caps = {
    "platformName": "Android",
    "platformVersion": "11.0",
    "deviceName": "Android Emulator",
    "app": "/path/to/your/app.apk",
    "automationName": "UiAutomator2",
    "noReset": True
}

def test_cart_flow():
    print("Starting Cart Test...")
    
    # Initialize driver
    driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)
    wait = WebDriverWait(driver, 10)
    
    try:
        # Login first (assuming we're logged out)
        print("Logging in...")
        email_field = wait.until(
            EC.presence_of_element_located((AppiumBy.ID, "email_field"))
        )
        email_field.send_keys("test@test.com")  # Use existing test account
        
        password_field = driver.find_element(AppiumBy.ID, "password_field")
        password_field.send_keys("Password123")
        
        login_button = driver.find_element(AppiumBy.ID, "login_button")
        login_button.click()
        
        # Wait for home screen
        wait.until(
            EC.presence_of_element_located((AppiumBy.ID, "home_screen"))
        )
        
        # Open first product
        print("Opening product...")
        first_product = wait.until(
            EC.presence_of_element_located((AppiumBy.XPATH, "//android.widget.Button[1]"))
        )
        first_product.click()
        
        # Add to cart
        print("Adding to cart...")
        add_to_cart_button = wait.until(
            EC.presence_of_element_located((AppiumBy.ID, "add_to_cart_button"))
        )
        add_to_cart_button.click()
        
        # Go to cart
        print("Going to cart...")
        cart_button = wait.until(
            EC.presence_of_element_located((AppiumBy.ID, "cart_button"))
        )
        cart_button.click()
        
        # Verify item in cart
        print("Verifying item in cart...")
        cart_item = wait.until(
            EC.presence_of_element_located((AppiumBy.ID, "cart_item"))
        )
        
        # Remove item for cleanup
        remove_button = driver.find_element(AppiumBy.ID, "remove_button")
        remove_button.click()
        
        print("✓ Cart test PASSED!")
        return True
        
    except Exception as e:
        print(f"✗ Cart test FAILED: {str(e)}")
        # Take screenshot
        driver.save_screenshot("cart_test_failure.png")
        return False
        
    finally:
        driver.quit()

if __name__ == "__main__":
    test_cart_flow()