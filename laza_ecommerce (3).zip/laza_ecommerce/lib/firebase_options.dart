// lib/firebase_options.dart
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.windows:
        return web; // Windows Flutter uses Web Firebase config
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  /// 🔹 ANDROID
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'PUT_ANDROID_API_KEY_HERE',
    appId: '1:377608424398:android:bca748769544fac3f3b99f',
    messagingSenderId: '377608424398',
    projectId: 'laza_ecommerce',
    storageBucket: 'laza_ecommerce.appspot.com',
  );

  /// 🔹 WEB
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: "AIzaSyCIq9WHJ3S8N1I55YA66N68UxpEdf8B1v8",
  authDomain: "laza-ecommerce-2c01c.firebaseapp.com",
  projectId: "laza-ecommerce-2c01c",
  storageBucket: "laza-ecommerce-2c01c.firebasestorage.app",
  messagingSenderId: "377608424398",
  appId: "1:377608424398:web:f6d5dc60b1795825f3b99f",
  measurementId: "G-E3NVVZ5L18"
  );

}
