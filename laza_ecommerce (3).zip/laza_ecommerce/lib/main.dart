import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'firebase_options.dart';

// Import models
import 'data/models/product_model.dart';
import 'data/models/cart_item_model.dart';
import 'data/models/address_model.dart';
import 'data/models/card_model.dart';

// Import only screens that definitely exist
import 'presentation/screens/auth/login_screen.dart';
import 'presentation/screens/register_screen.dart';
import 'presentation/screens/onboarding_screen.dart';
import 'presentation/screens/home_screen.dart';
import 'presentation/screens/cart_screen.dart';
import 'presentation/screens/favorites_screen.dart';

// Import new password reset screens
import 'presentation/screens/forgot_password_screen.dart';
import 'presentation/screens/verification_code_screen.dart';
import 'presentation/screens/new_password_screen.dart';

// Import product detail and review screens
import 'presentation/screens/product_detail_screen.dart';
import 'presentation/screens/reviews_screen.dart';
import 'presentation/screens/add_review_screen.dart';

// Import checkout and payment screens
import 'presentation/screens/checkout_screen.dart';
import 'presentation/screens/payment_screen.dart';
import 'presentation/screens/address_screen.dart';
import 'presentation/screens/PaymentSuccessScreen.dart'; // Fixed import name
import 'presentation/screens/payment_method_screen.dart';
import 'presentation/screens/add_card_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Laza Ecommerce',
      
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          iconTheme: IconThemeData(color: Colors.white),
        ),
        colorScheme: ColorScheme.dark(
          primary: Colors.amberAccent,
          secondary: Colors.amberAccent,
        ),
        useMaterial3: true,
      ),

      initialRoute: '/',
      
      routes: {
        '/': (context) => const AuthWrapper(),
        '/onboarding': (context) => const OnboardingScreen(),
        '/login': (context) => const LoginScreen(),
        '/register': (context) => const RegisterScreen(),
        '/signup': (context) => const RegisterScreen(),
        
        // Password reset flow routes
        '/forgot-password': (context) => const ForgotPasswordScreen(),
        '/verification': (context) {
          final email = ModalRoute.of(context)!.settings.arguments as String? ?? '';
          return VerificationCodeScreen(email: email);
        },
        '/new-password': (context) {
          final args = ModalRoute.of(context)!.settings.arguments as Map<String, String>?;
          return NewPasswordScreen(
            email: args?['email'] ?? '',
            code: args?['code'] ?? '',
          );
        },
        
        // Main app screens
        '/home': (context) => const HomeScreen(),
        '/cart': (context) => const CartScreen(),
        '/favorites': (context) => const FavoritesScreen(),
        
        // Product detail and review screens
        '/product-detail': (context) {
          final product = ModalRoute.of(context)!.settings.arguments;
          if (product == null) {
            return _buildErrorScreen('Product not found', context);
          }
          return ProductDetailsScreen(product: product as Product);
        },
        '/reviews': (context) {
          final product = ModalRoute.of(context)!.settings.arguments;
          if (product == null) {
            return _buildErrorScreen('Product not found', context);
          }
          return ReviewsScreen(product: product as Product);
        },
        '/add-review': (context) {
          final product = ModalRoute.of(context)!.settings.arguments;
          if (product == null) {
            return _buildErrorScreen('Product not found', context);
          }
          return AddReviewScreen(product: product as Product);
        },
        
        // Checkout and payment flow
        '/checkout': (context) {
          final items = ModalRoute.of(context)!.settings.arguments;
          if (items == null || items is! List<CartItem>) {
            return _buildErrorScreen('Cart items not found', context);
          }
          return CheckoutScreen(cartItems: items as List<CartItem>);
        },
        '/payment': (context) {
          final args = ModalRoute.of(context)!.settings.arguments;
          if (args == null || args is! Map<String, dynamic>) {
            return _buildErrorScreen('Payment details not found', context);
          }
          
          // Extract all required parameters with null safety
          final items = args['items'] as List<CartItem>?;
          final totalAmount = args['totalAmount'] as double?;
          final shippingAddress = args['shippingAddress'] as Address?;
          final cardData = args['selectedCard'] as Map<String, dynamic>?;
          
          if (items == null || totalAmount == null || shippingAddress == null) {
            return _buildErrorScreen('Invalid payment details', context);
          }
          
          // Convert card data to CardModel if available
          CardModel? selectedCard;
          if (cardData != null) {
            try {
              selectedCard = CardModel.fromMap(cardData);
            } catch (e) {
              print('Error parsing card data: $e');
            }
          }
          
          return PaymentScreen(
            cartItems: items,
            totalAmount: totalAmount,
            shippingAddress: shippingAddress,
            selectedCard: selectedCard,
          );
        },
        
        // Address screen
        '/address': (context) {
          final existingAddress = ModalRoute.of(context)?.settings.arguments as Address?;
          return AddressScreen(existingAddress: existingAddress);
        },
        
        // Payment methods screens
        '/payment-methods': (context) => const PaymentMethodsScreen(),
        '/add-card': (context) => const AddCardScreen(),
        
        // Payment success screen - updated to match PaymentSuccessScreen constructor
        '/payment-success': (context) {
          final args = ModalRoute.of(context)!.settings.arguments;
          if (args == null || args is! Map<String, dynamic>) {
            return _buildErrorScreen('Order details not found', context);
          }
          return PaymentSuccessScreen(orderData: args); // Changed from orderDetails to orderData
        },
        
        // Alias for order-confirmed to payment-success for backward compatibility
        '/order-confirmed': (context) {
          final args = ModalRoute.of(context)!.settings.arguments;
          if (args == null || args is! Map<String, dynamic>) {
            return _buildErrorScreen('Order details not found', context);
          }
          return PaymentSuccessScreen(orderData: args); // Changed from orderDetails to orderData
        },
      },
      
      // Handle unknown routes
      onUnknownRoute: (settings) {
        // Handle /signup specifically
        if (settings.name == '/signup') {
          return MaterialPageRoute(
            builder: (context) => const RegisterScreen(),
          );
        }
        
        return MaterialPageRoute(
          builder: (context) => Scaffold(
            backgroundColor: Colors.black,
            appBar: AppBar(
              title: const Text('Page Not Found'),
            ),
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.error_outline,
                    size: 60,
                    color: Colors.redAccent,
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'Screen Not Found',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Route: ${settings.name}',
                    style: TextStyle(
                      color: Colors.grey.shade400,
                    ),
                  ),
                  const SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pushReplacementNamed(context, '/home');
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.amberAccent,
                      foregroundColor: Colors.black,
                    ),
                    child: const Text('Go to Home'),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // Helper function to build error screens
  static Widget _buildErrorScreen(String message, BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error, color: Colors.red, size: 50),
            const SizedBox(height: 20),
            Text(
              message,
              style: const TextStyle(color: Colors.white, fontSize: 18),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.amberAccent,
                foregroundColor: Colors.black,
              ),
              child: const Text('Go Back'),
            ),
          ],
        ),
      ),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            backgroundColor: Colors.black,
            body: Center(
              child: CircularProgressIndicator(
                color: Colors.amberAccent,
              ),
            ),
          );
        }

        if (snapshot.hasData && snapshot.data != null) {
          return const HomeScreen();
        }

        return const OnboardingScreen();
      },
    );
  }
}