import 'package:cloud_firestore/cloud_firestore.dart';

class CartItem {
  final String productId;
  final String title;
  final String image;
  final double price;
  int quantity;
  final String? size;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  CartItem({
    required this.productId,
    required this.title,
    required this.image,
    required this.price,
    required this.quantity,
    this.size,
    this.createdAt,
    this.updatedAt,
  });

  factory CartItem.fromMap(Map<String, dynamic> data) {
    return CartItem(
      productId: data['productId'] ?? '',
      title: data['title'] ?? '',
      image: data['image'] ?? '',
      price: (data['price'] is num ? data['price'] as num : 0).toDouble(),
      quantity: data['quantity'] is int ? data['quantity'] as int : 1,
      size: data['size'],
      createdAt: data['createdAt'] != null 
          ? DateTime.parse(data['createdAt']) 
          : null,
      updatedAt: data['updatedAt'] != null 
          ? DateTime.parse(data['updatedAt']) 
          : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'productId': productId,
      'title': title,
      'image': image,
      'price': price,
      'quantity': quantity,
      'size': size,
      'createdAt': createdAt?.toIso8601String() ?? DateTime.now().toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String() ?? DateTime.now().toIso8601String(),
    };
  }

  // Create a copyWith method for easy updates
  CartItem copyWith({
    String? productId,
    String? title,
    String? image,
    double? price,
    int? quantity,
    String? size,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return CartItem(
      productId: productId ?? this.productId,
      title: title ?? this.title,
      image: image ?? this.image,
      price: price ?? this.price,
      quantity: quantity ?? this.quantity,
      size: size ?? this.size,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  // Get total price
  double get total => price * quantity;

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is CartItem &&
        other.productId == productId &&
        other.size == size;
  }

  @override
  int get hashCode => productId.hashCode ^ (size?.hashCode ?? 0);
  
  @override
  String toString() {
    return 'CartItem(productId: $productId, title: $title, quantity: $quantity, size: $size)';
  }
}