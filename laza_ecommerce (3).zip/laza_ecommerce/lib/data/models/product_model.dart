class Product {
  final int id;
  final String title;
  final double price;
  final String description;
  final String category;
  final String image;
  final Rating rating;
  final List<String>? sizes;
  final List<String>? colors;
  final bool? isFeatured;
  final bool? isNewArrival;
  final double? discount;
  final String? brand;
  final int? stock;
  final List<String>? images;

  Product({
    required this.id,
    required this.title,
    required this.price,
    required this.description,
    required this.category,
    required this.image,
    required this.rating,
    this.sizes,
    this.colors,
    this.isFeatured,
    this.isNewArrival,
    this.discount,
    this.brand,
    this.stock,
    this.images,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    // Handle both APIs - Fake Store API and Platzi Fake API
    return Product(
      id: json['id'] is String ? int.parse(json['id']) : json['id'],
      title: json['title'] ?? json['name'] ?? 'No Title',
      price: (json['price'] as num).toDouble(),
      description: json['description'] ?? '',
      category: json['category'] ?? json['categoryId']?.toString() ?? 'Uncategorized',
      image: json['image'] ?? json['images']?.first ?? '',
      rating: Rating.fromJson(json['rating'] ?? {}),
      sizes: json['sizes'] != null 
          ? List<String>.from(json['sizes'])
          : ['S', 'M', 'L', 'XL', '2XL'],
      colors: json['colors'] != null 
          ? List<String>.from(json['colors'])
          : null,
      isFeatured: json['isFeatured'] ?? json['featured'] ?? false,
      isNewArrival: json['isNewArrival'] ?? false,
      discount: json['discount']?.toDouble() ?? json['discountPercentage']?.toDouble(),
      brand: json['brand'] ?? 'Unknown',
      stock: json['stock'] ?? json['quantity'] ?? 100,
      images: json['images'] != null 
          ? List<String>.from(json['images'])
          : [json['image'] ?? ''],
    );
  }

  // Get discounted price
  double get discountedPrice {
    if (discount != null && discount! > 0) {
      return price - (price * discount! / 100);
    }
    return price;
  }

  // Check if product is on sale
  bool get isOnSale => discount != null && discount! > 0;

  // Check if product is in stock
  bool get inStock => (stock ?? 0) > 0;

  // Create a map for Firestore or local storage
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'price': price,
      'description': description,
      'category': category,
      'image': image,
      'rating': rating.toJson(),
      'sizes': sizes,
      'colors': colors,
      'isFeatured': isFeatured,
      'isNewArrival': isNewArrival,
      'discount': discount,
      'brand': brand,
      'stock': stock,
      'images': images,
    };
  }

  // Create a copyWith method
  Product copyWith({
    int? id,
    String? title,
    double? price,
    String? description,
    String? category,
    String? image,
    Rating? rating,
    List<String>? sizes,
    List<String>? colors,
    bool? isFeatured,
    bool? isNewArrival,
    double? discount,
    String? brand,
    int? stock,
    List<String>? images,
  }) {
    return Product(
      id: id ?? this.id,
      title: title ?? this.title,
      price: price ?? this.price,
      description: description ?? this.description,
      category: category ?? this.category,
      image: image ?? this.image,
      rating: rating ?? this.rating,
      sizes: sizes ?? this.sizes,
      colors: colors ?? this.colors,
      isFeatured: isFeatured ?? this.isFeatured,
      isNewArrival: isNewArrival ?? this.isNewArrival,
      discount: discount ?? this.discount,
      brand: brand ?? this.brand,
      stock: stock ?? this.stock,
      images: images ?? this.images,
    );
  }
}

class Rating {
  final double rate;
  final int count;

  Rating({required this.rate, required this.count});

  factory Rating.fromJson(Map<String, dynamic> json) {
    // Handle both rate formats
    return Rating(
      rate: (json['rate'] as num?)?.toDouble() ?? 
            (json['rating'] as num?)?.toDouble() ?? 0.0,
      count: json['count'] ?? json['reviews'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'rate': rate,
      'count': count,
    };
  }

  // Get star rating display
  String get starRating {
    return rate.toStringAsFixed(1);
  }

  // Get filled stars count
  int get filledStars => rate.floor();

  // Check if has half star
  bool get hasHalfStar => (rate - filledStars) >= 0.5;
}