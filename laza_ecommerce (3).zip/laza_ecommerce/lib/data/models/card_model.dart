import 'package:cloud_firestore/cloud_firestore.dart';

class CardModel {
  final String id;
  final String userId;
  final String cardHolderName;
  final String cardNumber; // Store last 4 digits only for security
  final String cardType; // 'visa', 'mastercard', 'amex', etc.
  final String expiryMonth;
  final String expiryYear;
  final String cvv; // Note: CVV should NOT be stored in database
  final bool isDefault;
  final DateTime createdAt;
  final DateTime updatedAt;

  CardModel({
    required this.id,
    required this.userId,
    required this.cardHolderName,
    required this.cardNumber, // Last 4 digits
    required this.cardType,
    required this.expiryMonth,
    required this.expiryYear,
    required this.cvv, // Only for temporary use, not stored
    required this.isDefault,
    required this.createdAt,
    required this.updatedAt,
  });

  // Get formatted expiry date
  String get formattedExpiry => '$expiryMonth/$expiryYear';

  // Get masked card number for display
  String get maskedCardNumber {
    if (cardNumber.length <= 4) return '•••• $cardNumber';
    return '•••• •••• •••• ${cardNumber.substring(cardNumber.length - 4)}';
  }

  // Get full masked number
  String get fullMaskedCardNumber {
    return '•••• •••• •••• ${cardNumber.substring(cardNumber.length - 4)}';
  }

  // Get card type icon
  String get cardTypeIcon {
    switch (cardType.toLowerCase()) {
      case 'visa':
        return 'assets/icons/visa.png';
      case 'mastercard':
        return 'assets/icons/mastercard.png';
      case 'amex':
        return 'assets/icons/amex.png';
      case 'discover':
        return 'assets/icons/discover.png';
      default:
        return 'assets/icons/credit_card.png';
    }
  }

  // Convert to Map for Firestore
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'userId': userId,
      'cardHolderName': cardHolderName,
      'cardNumber': cardNumber, // Store only last 4 digits
      'cardType': cardType,
      'expiryMonth': expiryMonth,
      'expiryYear': expiryYear,
      'isDefault': isDefault,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
    };
  }

  // Create from Firestore Document
  factory CardModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return CardModel(
      id: data['id'] ?? doc.id,
      userId: data['userId'] ?? '',
      cardHolderName: data['cardHolderName'] ?? '',
      cardNumber: data['cardNumber'] ?? '',
      cardType: data['cardType'] ?? 'visa',
      expiryMonth: data['expiryMonth'] ?? '',
      expiryYear: data['expiryYear'] ?? '',
      cvv: '', // Not stored in database
      isDefault: data['isDefault'] ?? false,
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      updatedAt: (data['updatedAt'] as Timestamp).toDate(),
    );
  }

  // Create from Map
  factory CardModel.fromMap(Map<String, dynamic> map) {
    return CardModel(
      id: map['id'] ?? '',
      userId: map['userId'] ?? '',
      cardHolderName: map['cardHolderName'] ?? '',
      cardNumber: map['cardNumber'] ?? '',
      cardType: map['cardType'] ?? 'visa',
      expiryMonth: map['expiryMonth'] ?? '',
      expiryYear: map['expiryYear'] ?? '',
      cvv: map['cvv'] ?? '',
      isDefault: map['isDefault'] ?? false,
      createdAt: map['createdAt'] is Timestamp
          ? (map['createdAt'] as Timestamp).toDate()
          : DateTime.parse(map['createdAt'].toString()),
      updatedAt: map['updatedAt'] is Timestamp
          ? (map['updatedAt'] as Timestamp).toDate()
          : DateTime.parse(map['updatedAt'].toString()),
    );
  }

  // Copy with method for updates
  CardModel copyWith({
    String? id,
    String? userId,
    String? cardHolderName,
    String? cardNumber,
    String? cardType,
    String? expiryMonth,
    String? expiryYear,
    String? cvv,
    bool? isDefault,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return CardModel(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      cardHolderName: cardHolderName ?? this.cardHolderName,
      cardNumber: cardNumber ?? this.cardNumber,
      cardType: cardType ?? this.cardType,
      expiryMonth: expiryMonth ?? this.expiryMonth,
      expiryYear: expiryYear ?? this.expiryYear,
      cvv: cvv ?? this.cvv,
      isDefault: isDefault ?? this.isDefault,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  // Helper to detect card type from number
  static String detectCardType(String cardNumber) {
    final cleaned = cardNumber.replaceAll(RegExp(r'[^0-9]'), '');
    
    if (cleaned.startsWith('4')) return 'visa';
    if (cleaned.startsWith('5')) return 'mastercard';
    if (cleaned.startsWith('3')) return 'amex';
    if (cleaned.startsWith('6')) return 'discover';
    
    return 'credit_card';
  }

  // Validate card
  bool get isValid {
    final cleanedNumber = cardNumber.replaceAll(RegExp(r'[^0-9]'), '');
    return cardHolderName.isNotEmpty &&
        cleanedNumber.length >= 4 &&
        expiryMonth.isNotEmpty &&
        expiryYear.isNotEmpty &&
        expiryMonth.length == 2 &&
        expiryYear.length == 2;
  }

  @override
  String toString() {
    return 'CardModel(id: $id, cardHolderName: $cardHolderName, last4: ${cardNumber.substring(cardNumber.length - 4)}, isDefault: $isDefault)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is CardModel && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}