import 'package:cloud_firestore/cloud_firestore.dart';

class Address {
  final String id;
  final String userId;
  final String name;
  final String country;
  final String city;
  final String state;
  final String zipCode;
  final String phone;
  final String addressLine1;
  final String? addressLine2;
  final bool isPrimary;
  final String label;
  final DateTime createdAt;
  final DateTime updatedAt;

  Address({
    required this.id,
    required this.userId,
    required this.name,
    required this.country,
    required this.city,
    required this.state,
    required this.zipCode,
    required this.phone,
    required this.addressLine1,
    this.addressLine2,
    required this.isPrimary,
    required this.label,
    required this.createdAt,
    required this.updatedAt,
  });

  // Convert to Map for Firestore
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'userId': userId,
      'name': name,
      'country': country,
      'city': city,
      'state': state,
      'zipCode': zipCode,
      'phone': phone,
      'addressLine1': addressLine1,
      'addressLine2': addressLine2,
      'isPrimary': isPrimary,
      'label': label,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
    };
  }

  // Create from Firestore Document
  factory Address.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Address(
      id: data['id'] ?? doc.id,
      userId: data['userId'] ?? '',
      name: data['name'] ?? '',
      country: data['country'] ?? '',
      city: data['city'] ?? '',
      state: data['state'] ?? '',
      zipCode: data['zipCode'] ?? '',
      phone: data['phone'] ?? '',
      addressLine1: data['addressLine1'] ?? '',
      addressLine2: data['addressLine2'],
      isPrimary: data['isPrimary'] ?? false,
      label: data['label'] ?? 'Home',
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      updatedAt: (data['updatedAt'] as Timestamp).toDate(),
    );
  }

  // ADD THIS METHOD: Create from Map (for passing between screens)
  factory Address.fromMap(Map<String, dynamic> map) {
    return Address(
      id: map['id'] ?? '',
      userId: map['userId'] ?? '',
      name: map['name'] ?? '',
      country: map['country'] ?? '',
      city: map['city'] ?? '',
      state: map['state'] ?? '',
      zipCode: map['zipCode'] ?? '',
      phone: map['phone'] ?? '',
      addressLine1: map['addressLine1'] ?? '',
      addressLine2: map['addressLine2'],
      isPrimary: map['isPrimary'] ?? false,
      label: map['label'] ?? 'Home',
      createdAt: map['createdAt'] is Timestamp 
          ? (map['createdAt'] as Timestamp).toDate()
          : (map['createdAt'] is DateTime 
              ? map['createdAt'] as DateTime
              : DateTime.parse(map['createdAt'].toString())),
      updatedAt: map['updatedAt'] is Timestamp
          ? (map['updatedAt'] as Timestamp).toDate()
          : (map['updatedAt'] is DateTime
              ? map['updatedAt'] as DateTime
              : DateTime.parse(map['updatedAt'].toString())),
    );
  }

  // Copy with method for updates
  Address copyWith({
    String? id,
    String? userId,
    String? name,
    String? country,
    String? city,
    String? state,
    String? zipCode,
    String? phone,
    String? addressLine1,
    String? addressLine2,
    bool? isPrimary,
    String? label,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Address(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      name: name ?? this.name,
      country: country ?? this.country,
      city: city ?? this.city,
      state: state ?? this.state,
      zipCode: zipCode ?? this.zipCode,
      phone: phone ?? this.phone,
      addressLine1: addressLine1 ?? this.addressLine1,
      addressLine2: addressLine2 ?? this.addressLine2,
      isPrimary: isPrimary ?? this.isPrimary,
      label: label ?? this.label,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  // Check if address is valid
  bool get isValid => 
      name.isNotEmpty &&
      country.isNotEmpty &&
      city.isNotEmpty &&
      state.isNotEmpty &&
      zipCode.isNotEmpty &&
      phone.isNotEmpty &&
      addressLine1.isNotEmpty;

  // Get formatted address string
  String get formattedAddress {
    String address = addressLine1;
    if (addressLine2 != null && addressLine2!.isNotEmpty) {
      address += ', $addressLine2';
    }
    address += ', $city, $state $zipCode, $country';
    return address;
  }

  // ADD THIS: Convert to simple Map for passing between screens
  Map<String, dynamic> toSimpleMap() {
    return {
      'id': id,
      'userId': userId,
      'name': name,
      'country': country,
      'city': city,
      'state': state,
      'zipCode': zipCode,
      'phone': phone,
      'addressLine1': addressLine1,
      'addressLine2': addressLine2,
      'isPrimary': isPrimary,
      'label': label,
      'createdAt': createdAt.toIso8601String(), // Convert DateTime to String
      'updatedAt': updatedAt.toIso8601String(), // Convert DateTime to String
    };
  }

  @override
  String toString() {
    return 'Address(id: $id, name: $name, city: $city, isPrimary: $isPrimary)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Address && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}