import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/product_model.dart';

class ProductRepository {
  // Using Fake Store API (reliable and working)
  static const String baseUrl = 'https://fakestoreapi.com';
  
  // Local cache for products
  List<Product>? _cachedProducts;

  Future<List<Product>> getProducts({
    String? category,
    bool featuredOnly = false,
    bool newArrivalsOnly = false,
    int limit = 0,
    int offset = 0,
  }) async {
    try {
      print('📡 Fetching products from $baseUrl...');
      
      String url = '$baseUrl/products';
      
      // Handle category
      if (category != null && category.isNotEmpty) {
        url = '$baseUrl/products/category/$category';
      }
      
      final response = await http.get(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      );
      
      print('✅ Response status: ${response.statusCode}');
      
      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        print('🎉 Successfully loaded ${data.length} products');
        
        List<Product> products = data.map((json) => Product.fromJson(json)).toList();
        
        // Fake Store API doesn't have featured/new arrival flags
        // So we'll mark some products as featured/new for demo
        products = _enhanceProducts(products);
        
        // Apply filters
        if (featuredOnly) {
          products = products.where((p) => p.isFeatured == true).toList();
        }
        
        if (newArrivalsOnly) {
          products = products.where((p) => p.isNewArrival == true).toList();
        }
        
        // Apply limit
        if (limit > 0 && limit < products.length) {
          products = products.sublist(0, limit);
        }
        
        // Apply offset (simple implementation)
        if (offset > 0 && offset < products.length) {
          products = products.sublist(offset);
        }
        
        // Cache the results
        _cachedProducts = products;
        
        return products;
      } else {
        print('❌ API Error: ${response.statusCode} - ${response.body}');
        throw Exception('Failed to load products: ${response.statusCode}');
      }
    } catch (e) {
      print('💥 Error loading products: $e');
      // Return cached products if available
      if (_cachedProducts != null) {
        print('🔄 Returning cached products');
        return _cachedProducts!;
      }
      
      // If no cache, return demo products
      print('📦 Returning demo products');
      return _getDemoProducts();
    }
  }

  // Enhance products with additional data for demo
  List<Product> _enhanceProducts(List<Product> products) {
    return products.asMap().entries.map((entry) {
      final index = entry.key;
      final product = entry.value;
      
      // Mark first 3 products as featured
      final isFeatured = index < 3;
      
      // Mark first 6 products as new arrivals
      final isNewArrival = index < 6;
      
      // Add some discounts randomly
      final hasDiscount = index % 3 == 0;
      final discount = hasDiscount ? (10 + (index % 20)).toDouble() : null;
      
      // Add brand based on category
      String? brand;
      if (product.category.contains('electronics')) {
        brand = index % 2 == 0 ? 'Samsung' : 'Apple';
      } else if (product.category.contains('jewelery')) {
        brand = 'Tiffany & Co.';
      } else if (product.category.contains("men's clothing")) {
        brand = index % 2 == 0 ? 'Nike' : 'Adidas';
      } else if (product.category.contains("women's clothing")) {
        brand = index % 2 == 0 ? 'Zara' : 'H&M';
      }
      
      // Add sizes
      final List<String> sizes = ['S', 'M', 'L', 'XL', '2XL'];
      
      return product.copyWith(
        isFeatured: isFeatured,
        isNewArrival: isNewArrival,
        discount: discount,
        brand: brand,
        sizes: sizes,
      );
    }).toList();
  }

  // Get demo products for fallback - FIXED URL
  List<Product> _getDemoProducts() {
    return [
      Product(
        id: 1,
        title: 'Nike Air Max 270',
        price: 149.99,
        description: 'Step into comfort and style with the Nike Air Max 270. Featuring the tallest Max Air unit yet for maximum cushioning.',
        category: "men's clothing",
        image: 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/af53d53d-561f-450a-a483-5a356eee6fbf/air-max-270-mens-shoes-KkLcGR.png',
        rating: Rating(rate: 4.5, count: 120),
        isFeatured: true,
        isNewArrival: true,
        discount: 15.0,
        brand: 'Nike',
        sizes: ['S', 'M', 'L', 'XL'],
      ),
      Product(
        id: 2,
        title: 'Adidas Ultraboost 22',
        price: 179.99,
        description: 'Experience high-performance running with Adidas Ultraboost 22. Responsive cushioning for all-day comfort.',
        category: "men's clothing",
        image: 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/1f7d7b8f1f9a4e6c8f76afb900e3c0b6_9366/Ultraboost_22_Shoes_Black_GZ9257_01_standard.jpg',
        rating: Rating(rate: 4.8, count: 89),
        isFeatured: true,
        isNewArrival: true,
        discount: 10.0,
        brand: 'Adidas',
        sizes: ['S', 'M', 'L'],
      ),
      Product(
        id: 3,
        title: 'Fila Disruptor II',
        price: 89.99,
        description: 'Make a bold statement with Fila Disruptor II. Chunky design meets modern style for everyday wear.',
        category: "women's clothing",
        image: 'https://images.fila.com/Is/image/FilaUS/1TW00457_001_main', // Removed the query parameter
        rating: Rating(rate: 4.3, count: 67),
        isFeatured: true,
        isNewArrival: true,
        brand: 'Fila',
        sizes: ['M', 'L', 'XL'],
      ),
      Product(
        id: 4,
        title: 'Puma RS-X Reinvention',
        price: 109.99,
        description: 'Bold and futuristic sneakers from Puma. RS-X technology for superior comfort and style.',
        category: "men's clothing",
        image: 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_2000,h_2000/global/370634/01/sv01/fnd/EEA/fmt/png/RS-X-Reinvention-Men\'s-Sneakers',
        rating: Rating(rate: 4.6, count: 45),
        isNewArrival: true,
        discount: 20.0,
        brand: 'Puma',
        sizes: ['S', 'M', 'L', 'XL', '2XL'],
      ),
      Product(
        id: 5,
        title: 'Reebok Nano X2',
        price: 129.99,
        description: 'Training shoes built for performance. Flexible Floatride Energy foam for all-day comfort.',
        category: "men's clothing",
        image: 'https://www.reebok.com/dis/dw/image/v2/AAJP_PRD/on/demandware.static/-/Sites-reebok-products/default/dw03e7bd3f/zoom/H00461_01.jpg',
        rating: Rating(rate: 4.4, count: 78),
        isNewArrival: true,
        brand: 'Reebok',
        sizes: ['M', 'L', 'XL'],
      ),
    ];
  }

  Future<Product> getProductById(int id) async {
    try {
      print('📡 Fetching product $id from $baseUrl...');
      
      final response = await http.get(
        Uri.parse('$baseUrl/products/$id'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      );
      
      if (response.statusCode == 200) {
        final product = Product.fromJson(json.decode(response.body));
        print('✅ Successfully loaded product: ${product.title}');
        
        // Enhance with demo data
        return product.copyWith(
          isNewArrival: id < 10, // Mark early IDs as new arrivals
          discount: id % 3 == 0 ? 15.0 : null,
          brand: _getBrandForId(id),
          sizes: ['S', 'M', 'L', 'XL'],
        );
      } else {
        throw Exception('Failed to load product: ${response.statusCode}');
      }
    } catch (e) {
      print('💥 Error loading product $id: $e');
      
      // Return demo product if API fails
      final demoProducts = _getDemoProducts();
      if (id <= demoProducts.length) {
        return demoProducts[id - 1];
      }
      
      // Create a generic product
      return Product(
        id: id,
        title: 'Product $id',
        price: 99.99,
        description: 'This is product number $id',
        category: 'General',
        image: 'https://via.placeholder.com/300',
        rating: Rating(rate: 4.0, count: 50),
        brand: 'Brand $id',
        sizes: ['S', 'M', 'L'],
      );
    }
  }

  String _getBrandForId(int id) {
    final brands = ['Nike', 'Adidas', 'Fila', 'Puma', 'Reebok'];
    return brands[id % brands.length];
  }

  Future<List<String>> getCategories() async {
    try {
      print('📡 Fetching categories from $baseUrl...');
      
      final response = await http.get(
        Uri.parse('$baseUrl/products/categories'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      );
      
      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        print('✅ Successfully loaded ${data.length} categories');
        return data.map((category) => category.toString()).toList();
      } else {
        print('❌ Failed to load categories: ${response.statusCode}');
        // Return default categories
        return [
          "men's clothing",
          "women's clothing",
          'jewelery',
          'electronics',
        ];
      }
    } catch (e) {
      print('💥 Error loading categories: $e');
      return [
        "men's clothing",
        "women's clothing",
        'jewelery',
        'electronics',
      ];
    }
  }

  Future<List<Product>> getProductsByCategory(String category) async {
    try {
      print('📡 Fetching products for category: $category');
      
      final response = await http.get(
        Uri.parse('$baseUrl/products/category/$category'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      );
      
      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        List<Product> products = data.map((json) => Product.fromJson(json)).toList();
        return _enhanceProducts(products);
      } else {
        throw Exception('Failed to load category products: ${response.statusCode}');
      }
    } catch (e) {
      print('💥 Error loading category $category: $e');
      return _getDemoProducts()
          .where((p) => p.category.toLowerCase().contains(category.toLowerCase()))
          .toList();
    }
  }

  Future<List<Product>> searchProducts(String query) async {
    try {
      final allProducts = await getProducts();
      
      return allProducts.where((product) {
        final titleMatch = product.title.toLowerCase().contains(query.toLowerCase());
        final categoryMatch = product.category.toLowerCase().contains(query.toLowerCase());
        final descriptionMatch = product.description.toLowerCase().contains(query.toLowerCase());
        final brandMatch = product.brand?.toLowerCase().contains(query.toLowerCase()) ?? false;
        
        return titleMatch || categoryMatch || descriptionMatch || brandMatch;
      }).toList();
    } catch (e) {
      print('💥 Error searching products: $e');
      return _getDemoProducts()
          .where((p) => p.title.toLowerCase().contains(query.toLowerCase()))
          .toList();
    }
  }

  // Get featured products
  Future<List<Product>> getFeaturedProducts() async {
    try {
      final products = await getProducts();
      return products.where((p) => p.isFeatured == true).toList();
    } catch (e) {
      print('💥 Error loading featured products: $e');
      return _getDemoProducts().where((p) => p.isFeatured == true).toList();
    }
  }

  // Get new arrival products
  Future<List<Product>> getNewArrivals() async {
    try {
      print('🆕 Fetching new arrivals...');
      // Get all products and filter for new arrivals
      final products = await getProducts();
      final newArrivals = products.where((p) => p.isNewArrival == true).toList();
      
      // If we don't have enough new arrivals, mark some as new
      if (newArrivals.length < 4) {
        return products.take(8).map((p) => p.copyWith(isNewArrival: true)).toList();
      }
      
      return newArrivals.take(8).toList();
    } catch (e) {
      print('💥 Error loading new arrivals: $e');
      return _getDemoProducts().where((p) => p.isNewArrival == true).toList();
    }
  }

  // Get limited number of products for home screen
  Future<List<Product>> getHomeProducts({int limit = 8}) async {
    return getProducts(limit: limit);
  }

  // Get products sorted by price
  Future<List<Product>> getProductsSortedByPrice({bool ascending = true}) async {
    final products = await getProducts();
    products.sort((a, b) {
      if (ascending) {
        return a.price.compareTo(b.price);
      } else {
        return b.price.compareTo(a.price);
      }
    });
    return products;
  }

  // Get products sorted by rating
  Future<List<Product>> getProductsSortedByRating({bool descending = true}) async {
    final products = await getProducts();
    products.sort((a, b) {
      if (descending) {
        return b.rating.rate.compareTo(a.rating.rate);
      } else {
        return a.rating.rate.compareTo(b.rating.rate);
      }
    });
    return products;
  }

  // Get products with pagination
  Future<List<Product>> getProductsWithPagination(int page, int limit) async {
    final offset = (page - 1) * limit;
    return getProducts(limit: limit, offset: offset);
  }
}