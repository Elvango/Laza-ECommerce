import 'package:laza_ecommerce/data/models/review_model.dart';

class ReviewRepository {
  // Private constructor
  ReviewRepository._privateConstructor();
  
  // Static instance
  static final ReviewRepository _instance = ReviewRepository._privateConstructor();
  
  // Factory constructor to return the same instance
  factory ReviewRepository() {
    return _instance;
  }
  
  final List<Review> _reviews = [
    Review(
      id: '1',
      productId: '1',
      userId: '1',
      userName: 'Jenny Wilson',
      rating: 4.8,
      comment: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque malesuada eget vitae amet...',
      date: DateTime(2020, 9, 13),
    ),
    Review(
      id: '2',
      productId: '1',
      userId: '2',
      userName: 'Ronald Richards',
      rating: 4.8,
      comment: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque malesuada eget vitae amet...',
      date: DateTime(2020, 9, 13),
    ),
    Review(
      id: '3',
      productId: '1',
      userId: '3',
      userName: 'Guy Hawkins',
      rating: 4.8,
      comment: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque malesuada eget vitae amet...',
      date: DateTime(2020, 9, 13),
    ),
    Review(
      id: '4',
      productId: '1',
      userId: '4',
      userName: 'Savannah Nguyen',
      rating: 4.8,
      comment: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque malesuada eget vitae amet...',
      date: DateTime(2020, 9, 13),
    ),
  ];

  Future<List<Review>> getReviewsByProduct(String productId) async {
    await Future.delayed(const Duration(milliseconds: 500));
    return _reviews.where((review) => review.productId == productId).toList();
  }

  Future<void> addReview(Review review) async {
    await Future.delayed(const Duration(milliseconds: 500));
    _reviews.add(review);
  }

  Future<double> getAverageRating(String productId) async {
    final productReviews = _reviews.where((r) => r.productId == productId).toList();
    if (productReviews.isEmpty) return 0.0;
    
    final totalRating = productReviews.fold(0.0, (sum, review) => sum + review.rating);
    return totalRating / productReviews.length;
  }

  Future<int> getReviewCount(String productId) async {
    return _reviews.where((review) => review.productId == productId).length;
  }
}