// lib/data/repositories/wishlist_repository.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:laza_ecommerce/data/models/product_model.dart';

class WishlistRepository {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<int> getWishlistCountStream(String userId) {
    if (userId.isEmpty) return Stream.value(0);
    
    return _firestore
        .collection('users')
        .doc(userId)
        .collection('wishlist')
        .snapshots()
        .map((snapshot) => snapshot.docs.length);
  }

  Future<void> addToWishlist(String userId, Product product) async {
    // Convert product.id to string for Firestore document ID
    final productId = product.id.toString();
    await _firestore
        .collection('users')
        .doc(userId)
        .collection('wishlist')
        .doc(productId)
        .set(product.toJson());
  }

  Future<void> removeFromWishlist(String userId, String productId) async {
    await _firestore
        .collection('users')
        .doc(userId)
        .collection('wishlist')
        .doc(productId)
        .delete();
  }

  Future<List<String>> getWishlistItemIds(String userId) async {
    if (userId.isEmpty) return [];
    
    final snapshot = await _firestore
        .collection('users')
        .doc(userId)
        .collection('wishlist')
        .get();
    
    return snapshot.docs.map((doc) => doc.id).toList();
  }

  Future<List<Product>> getWishlistItems(String userId) async {
    if (userId.isEmpty) return [];
    
    final snapshot = await _firestore
        .collection('users')
        .doc(userId)
        .collection('wishlist')
        .get();
    
    return snapshot.docs.map((doc) {
      final data = doc.data();
      // Ensure we have all required fields from the Product model
      return Product.fromJson(data);
    }).toList();
  }

  Stream<List<Product>> getWishlistStream(String userId) {
    if (userId.isEmpty) return Stream.value([]);
    
    return _firestore
        .collection('users')
        .doc(userId)
        .collection('wishlist')
        .snapshots()
        .map((snapshot) => 
            snapshot.docs.map((doc) => Product.fromJson(doc.data())).toList());
  }

  // Additional helper method to check if product is in wishlist
  Future<bool> isInWishlist(String userId, String productId) async {
    if (userId.isEmpty) return false;
    
    final doc = await _firestore
        .collection('users')
        .doc(userId)
        .collection('wishlist')
        .doc(productId)
        .get();
    
    return doc.exists;
  }
}