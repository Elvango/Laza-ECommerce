import 'package:uuid/uuid.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:laza_ecommerce/data/models/card_model.dart';

class CardRepository {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final Uuid _uuid = const Uuid();

  // Get current user ID
  String? get _userId => _auth.currentUser?.uid;

  // Save card to Firestore (only last 4 digits)
  Future<void> saveCard(CardModel card) async {
    try {
      final userId = _userId;
      if (userId == null) throw Exception('User not authenticated');

      // Extract last 4 digits for storage
      final cleanedNumber = card.cardNumber.replaceAll(RegExp(r'[^0-9]'), '');
      final last4Digits = cleanedNumber.length >= 4 
          ? cleanedNumber.substring(cleanedNumber.length - 4)
          : cleanedNumber;

      // Create card with last 4 digits only
      final cardToSave = card.copyWith(
        id: card.id.isEmpty ? _uuid.v4() : card.id,
        userId: userId,
        cardNumber: last4Digits,
        updatedAt: DateTime.now(),
      );

      // If this card is set as default, unset all other default cards
      if (cardToSave.isDefault) {
        await _unsetOtherDefaultCards(userId, cardToSave.id);
      }

      // Save to Firestore
      await _firestore
          .collection('users')
          .doc(userId)
          .collection('cards')
          .doc(cardToSave.id)
          .set(cardToSave.toMap());

      print('Card saved successfully: ${cardToSave.id}');
      
    } catch (e, stackTrace) {
      print('Error saving card: $e');
      print('Stack trace: $stackTrace');
      rethrow;
    }
  }

  // Get all cards for current user
  Future<List<CardModel>> getUserCards() async {
    try {
      final userId = _userId;
      if (userId == null) throw Exception('User not authenticated');

      final querySnapshot = await _firestore
          .collection('users')
          .doc(userId)
          .collection('cards')
          .orderBy('updatedAt', descending: true)
          .get();

      return querySnapshot.docs
          .map((doc) => CardModel.fromFirestore(doc))
          .toList();

    } catch (e) {
      print('Error getting cards: $e');
      return [];
    }
  }

  // Stream cards for real-time updates
  Stream<List<CardModel>> getUserCardsStream() {
    final userId = _userId;
    if (userId == null) {
      return Stream.value([]);
    }

    return _firestore
        .collection('users')
        .doc(userId)
        .collection('cards')
        .orderBy('updatedAt', descending: true)
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => CardModel.fromFirestore(doc)).toList())
        .handleError((error) {
          print('Error in cards stream: $error');
          return [];
        });
  }

  // Get default card
  Future<CardModel?> getDefaultCard() async {
    try {
      final cards = await getUserCards();
      
      if (cards.isEmpty) {
        return null;
      }
      
      // Try to find default card
      for (final card in cards) {
        if (card.isDefault) {
          return card;
        }
      }
      
      // If no default found, return first card
      return cards.first;
      
    } catch (e) {
      print('Error getting default card: $e');
      return null;
    }
  }

  // Set card as default
  Future<void> setCardAsDefault(String cardId) async {
    try {
      final userId = _userId;
      if (userId == null) throw Exception('User not authenticated');

      // First unset all other default cards
      await _unsetOtherDefaultCards(userId, cardId);
      
      // Then set this one as default
      await _firestore
          .collection('users')
          .doc(userId)
          .collection('cards')
          .doc(cardId)
          .update({
            'isDefault': true,
            'updatedAt': DateTime.now(),
          });
          
      print('Set card $cardId as default');
      
    } catch (e, stackTrace) {
      print('Error setting card as default: $e');
      print('Stack trace: $stackTrace');
      rethrow;
    }
  }

  // Delete card
  Future<void> deleteCard(String cardId) async {
    try {
      final userId = _userId;
      if (userId == null) throw Exception('User not authenticated');

      await _firestore
          .collection('users')
          .doc(userId)
          .collection('cards')
          .doc(cardId)
          .delete();

      print('Deleted card: $cardId');
      
    } catch (e) {
      print('Error deleting card: $e');
      rethrow;
    }
  }

  // Check if user has any cards
  Future<bool> hasCards() async {
    try {
      final userId = _userId;
      if (userId == null) return false;

      final snapshot = await _firestore
          .collection('users')
          .doc(userId)
          .collection('cards')
          .limit(1)
          .get();

      return snapshot.docs.isNotEmpty;
    } catch (e) {
      print('Error checking cards: $e');
      return false;
    }
  }

  // Private method to unset other default cards
  Future<void> _unsetOtherDefaultCards(String userId, String currentCardId) async {
    try {
      // Get ALL cards for this user first
      final querySnapshot = await _firestore
          .collection('users')
          .doc(userId)
          .collection('cards')
          .get();

      final batch = _firestore.batch();
      int unsetCount = 0;
      
      // Filter and update client-side
      for (final doc in querySnapshot.docs) {
        final data = doc.data();
        final isDefault = data['isDefault'] ?? false;
        final cardId = data['id'] ?? doc.id;
        
        if (isDefault == true && cardId != currentCardId) {
          batch.update(doc.reference, {'isDefault': false});
          unsetCount++;
        }
      }

      if (unsetCount > 0) {
        await batch.commit();
        print('Unset $unsetCount other default cards');
      }
    } catch (e, stackTrace) {
      print('Error unsetting other default cards: $e');
      print('Stack trace: $stackTrace');
      rethrow;
    }
  }

  // Get card by ID
  Future<CardModel?> getCardById(String cardId) async {
    try {
      final userId = _userId;
      if (userId == null) throw Exception('User not authenticated');

      final doc = await _firestore
          .collection('users')
          .doc(userId)
          .collection('cards')
          .doc(cardId)
          .get();

      if (doc.exists) {
        return CardModel.fromFirestore(doc);
      }
      
      return null;
      
    } catch (e) {
      print('Error getting card by ID: $e');
      return null;
    }
  }
}