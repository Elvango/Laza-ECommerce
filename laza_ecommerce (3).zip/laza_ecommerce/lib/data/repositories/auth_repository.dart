import 'package:firebase_auth/firebase_auth.dart';

class AuthRepository {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  // -----------------------------
  // Signup (Register)
  // -----------------------------
  Future<User?> signUp(String email, String password) async {
    try {
      final userCredential = await _firebaseAuth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      return userCredential.user;
    } on FirebaseAuthException catch (e) {
      throw FirebaseAuthException(
          code: e.code, message: e.message ?? 'Error during signup');
    }
  }

  // -----------------------------
  // Login
  // -----------------------------
  Future<User?> login(String email, String password) async {
    try {
      final userCredential = await _firebaseAuth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return userCredential.user;
    } on FirebaseAuthException catch (e) {
      throw FirebaseAuthException(
          code: e.code, message: e.message ?? 'Error during login');
    }
  }

  // -----------------------------
  // Logout
  // -----------------------------
  Future<void> signOut() async {
    await _firebaseAuth.signOut();
  }

  // -----------------------------
  // Current User (for Auto-login)
  // -----------------------------
  User? get currentUser => _firebaseAuth.currentUser;

  // -----------------------------
  // Reset Password
  // -----------------------------
  Future<void> resetPassword(String email) async {
    try {
      await _firebaseAuth.sendPasswordResetEmail(email: email);
    } on FirebaseAuthException catch (e) {
      throw FirebaseAuthException(
          code: e.code, message: e.message ?? 'Error sending reset email');
    }
  }
}
