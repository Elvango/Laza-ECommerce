import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:async';
import '../models/cart_item_model.dart';

class CartRepository {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final StreamController<List<CartItem>> _cartController = StreamController<List<CartItem>>.broadcast();
  
  // Local cache for offline support
  List<CartItem> _cartItems = [];

  String get _uid {
    final user = _auth.currentUser;
    if (user == null) {
      throw Exception('User not authenticated');
    }
    return user.uid;
  }

  CollectionReference get _cartRef =>
      _firestore.collection('users').doc(_uid).collection('cart');

  /// Generate a unique document ID based on product ID and size
  String _generateDocId(CartItem item) {
    if (item.size != null && item.size!.isNotEmpty) {
      return '${item.productId}_${item.size}';
    }
    return item.productId;
  }

  String _generateDocIdFromParams(String productId, {String? size}) {
    if (size != null && size.isNotEmpty) {
      return '${productId}_$size';
    }
    return productId;
  }

  /// Initialize cart repository
  CartRepository() {
    _initCartStream();
  }

  /// Initialize cart stream for real-time updates
  void _initCartStream() {
    try {
      _cartRef.snapshots().listen((snapshot) {
        final items = snapshot.docs
            .map((doc) {
              try {
                return CartItem.fromMap(doc.data() as Map<String, dynamic>);
              } catch (e) {
                print('Error parsing cart item ${doc.id}: $e');
                return null;
              }
            })
            .where((item) => item != null)
            .cast<CartItem>()
            .toList();
        _cartItems = items;
        _cartController.add(items);
      }, onError: (error) {
        print('Error in cart stream: $error');
        _cartController.addError(error);
      });
    } catch (e) {
      print('Error initializing cart stream: $e');
    }
  }

  /// Add product to cart with size support
  Future<void> addToCart(CartItem item) async {
    try {
      final docId = _generateDocId(item);
      final doc = _cartRef.doc(docId);
      final snapshot = await doc.get();

      if (snapshot.exists) {
        // If same product with same size exists, increment quantity
        final existingData = snapshot.data() as Map<String, dynamic>;
        final currentQuantity = (existingData['quantity'] is int 
            ? existingData['quantity'] as int 
            : (existingData['quantity'] as num).toInt());
        
        await doc.update({
          'quantity': currentQuantity + 1,
          'updatedAt': DateTime.now().toIso8601String(),
        });
      } else {
        // Add new item with timestamp
        final data = item.toMap();
        data['createdAt'] = DateTime.now().toIso8601String();
        data['updatedAt'] = DateTime.now().toIso8601String();
        await doc.set(data);
      }
    } catch (e) {
      print('Error adding to cart: $e');
      rethrow;
    }
  }

  /// Add to cart with custom quantity
  Future<void> addToCartWithQuantity(CartItem item, int quantity) async {
    try {
      final docId = _generateDocId(item);
      final data = item.toMap();
      data['quantity'] = quantity;
      data['createdAt'] = DateTime.now().toIso8601String();
      data['updatedAt'] = DateTime.now().toIso8601String();
      
      await _cartRef.doc(docId).set(data);
    } catch (e) {
      print('Error adding to cart with quantity: $e');
      rethrow;
    }
  }

  /// Remove a product from cart
  Future<void> removeFromCart(String productId, {String? size}) async {
    try {
      final docId = _generateDocIdFromParams(productId, size: size);
      await _cartRef.doc(docId).delete();
    } catch (e) {
      print('Error removing from cart: $e');
      rethrow;
    }
  }

  /// Update quantity of a product
  Future<void> updateQuantity(String productId, int quantity, {String? size}) async {
    try {
      final docId = _generateDocIdFromParams(productId, size: size);
      
      if (quantity <= 0) {
        await removeFromCart(productId, size: size);
      } else {
        await _cartRef.doc(docId).update({
          'quantity': quantity,
          'updatedAt': DateTime.now().toIso8601String(),
        });
      }
    } catch (e) {
      print('Error updating quantity: $e');
      rethrow;
    }
  }

  /// Update size of a cart item
  Future<void> updateSize(String productId, String oldSize, String newSize) async {
    try {
      if (oldSize == newSize) return;
      
      final oldDocId = '${productId}_$oldSize';
      final newDocId = '${productId}_$newSize';
      
      final snapshot = await _cartRef.doc(oldDocId).get();
      if (snapshot.exists) {
        final data = snapshot.data() as Map<String, dynamic>;
        data['size'] = newSize;
        data['updatedAt'] = DateTime.now().toIso8601String();
        
        // Write to new document and delete old one
        final batch = _firestore.batch();
        batch.set(_cartRef.doc(newDocId), data);
        batch.delete(_cartRef.doc(oldDocId));
        await batch.commit();
      }
    } catch (e) {
      print('Error updating size: $e');
      rethrow;
    }
  }

  /// Stream cart items for real-time updates
  Stream<List<CartItem>> getCartItems() {
    return _cartController.stream;
  }

  /// Get total cart value
  Future<double> getTotalPrice() async {
    try {
      final snapshot = await _cartRef.get();
      double total = 0;
      
      for (final doc in snapshot.docs) {
        final data = doc.data() as Map<String, dynamic>;
        final price = (data['price'] is num ? data['price'] as num : 0).toDouble();
        final quantity = data['quantity'] is int 
            ? data['quantity'] as int
            : (data['quantity'] is num ? (data['quantity'] as num).toInt() : 1);
        total += price * quantity;
      }
      
      return total;
    } catch (e) {
      print('Error getting total price: $e');
      return 0.0;
    }
  }

  /// Get total number of items in cart
  Future<int> getTotalItems() async {
    try {
      final snapshot = await _cartRef.get();
      int total = 0;
      
      for (final doc in snapshot.docs) {
        final data = doc.data() as Map<String, dynamic>;
        if (data['quantity'] is int) {
          total += data['quantity'] as int;
        } else if (data['quantity'] is num) {
          total += (data['quantity'] as num).toInt();
        } else {
          total += 1;
        }
      }
      
      return total;
    } catch (e) {
      print('Error getting total items: $e');
      return 0;
    }
  }

  /// Check if product is in cart
  Future<bool> isInCart(String productId, {String? size}) async {
    try {
      final docId = _generateDocIdFromParams(productId, size: size);
      final snapshot = await _cartRef.doc(docId).get();
      return snapshot.exists;
    } catch (e) {
      print('Error checking if in cart: $e');
      return false;
    }
  }

  /// Get cart item count stream for real-time badge updates
  Stream<int> getCartItemCountStream() {
    return _cartRef.snapshots().map((snapshot) {
      int total = 0;
      for (final doc in snapshot.docs) {
        final data = doc.data() as Map<String, dynamic>;
        if (data['quantity'] is int) {
          total += data['quantity'] as int;
        } else if (data['quantity'] is num) {
          total += (data['quantity'] as num).toInt();
        } else {
          total += 1;
        }
      }
      return total;
    });
  }

  /// Clear all items in cart
  Future<void> clearCart() async {
    try {
      print('Clearing cart for user: $_uid');
      final snapshot = await _cartRef.get();
      
      if (snapshot.docs.isEmpty) {
        print('Cart is already empty');
        return;
      }
      
      // Use batch delete for efficiency
      final batch = _firestore.batch();
      for (final doc in snapshot.docs) {
        batch.delete(doc.reference);
      }
      await batch.commit();
      
      // Clear local cache
      _cartItems.clear();
      _cartController.add([]);
      
      print('Cart cleared successfully. ${snapshot.docs.length} items removed.');
    } catch (e) {
      print('Error clearing cart: $e');
      rethrow;
    }
  }

  /// Get a specific cart item
  Future<CartItem?> getCartItem(String productId, {String? size}) async {
    try {
      final docId = _generateDocIdFromParams(productId, size: size);
      final snapshot = await _cartRef.doc(docId).get();
      
      if (snapshot.exists) {
        return CartItem.fromMap(snapshot.data() as Map<String, dynamic>);
      }
      return null;
    } catch (e) {
      print('Error getting cart item: $e');
      return null;
    }
  }

  /// Get cart items without streaming (one-time fetch)
  Future<List<CartItem>> fetchCartItems() async {
    try {
      final snapshot = await _cartRef.get();
      return snapshot.docs
          .map((doc) => CartItem.fromMap(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      print('Error fetching cart items: $e');
      return [];
    }
  }

  /// Check if cart is empty
  Future<bool> isCartEmpty() async {
    try {
      final snapshot = await _cartRef.get();
      return snapshot.docs.isEmpty;
    } catch (e) {
      print('Error checking if cart is empty: $e');
      return true;
    }
  }

  /// Calculate subtotal for display
  double calculateSubtotal(List<CartItem> items) {
    return items.fold(
      0.0,
      (sum, item) => sum + (item.price * item.quantity),
    );
  }

  /// Dispose the stream controller when done
  void dispose() {
    if (!_cartController.isClosed) {
      _cartController.close();
    }
  }

  /// Get current cart items from cache
  List<CartItem> getCachedCartItems() {
    return List.from(_cartItems);
  }
}