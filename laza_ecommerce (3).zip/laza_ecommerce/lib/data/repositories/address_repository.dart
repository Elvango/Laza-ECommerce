import 'package:uuid/uuid.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:laza_ecommerce/data/models/address_model.dart';

class AddressRepository {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final Uuid _uuid = const Uuid();

  // Get current user ID
  String? get _userId => _auth.currentUser?.uid;

  // Check if user has any addresses
  Future<bool> hasAddresses() async {
    try {
      final userId = _userId;
      if (userId == null) return false;

      final snapshot = await _firestore
          .collection('users')
          .doc(userId)
          .collection('addresses')
          .limit(1)
          .get();

      return snapshot.docs.isNotEmpty;
    } catch (e) {
      print('Error checking addresses: $e');
      return false;
    }
  }

  // Save address to Firestore
  Future<void> saveAddress(Address address) async {
    try {
      print('=== SAVE ADDRESS START ===');
      final userId = _userId;
      print('User ID: $userId');
      
      if (userId == null) {
        print('ERROR: User not authenticated');
        throw Exception('User not authenticated. Please log in.');
      }

      // Generate address ID if empty
      final addressId = address.id.isEmpty ? _uuid.v4() : address.id;
      
      // Create address with user ID and proper ID
      final addressWithUserId = address.copyWith(
        id: addressId,
        userId: userId,
        updatedAt: DateTime.now(),
      );

      print('Address to save: ${addressWithUserId.toMap()}');

      // If this address is set as primary, unset all other primary addresses
      if (addressWithUserId.isPrimary) {
        print('Setting as primary, unsetting others...');
        await _unsetOtherPrimaryAddresses(userId, addressWithUserId.id);
      }

      // Save to Firestore
      await _firestore
          .collection('users')
          .doc(userId)
          .collection('addresses')
          .doc(addressWithUserId.id)
          .set(addressWithUserId.toMap());

      print('=== SAVE ADDRESS SUCCESS ===');
      
    } catch (e, stackTrace) {
      print('=== SAVE ADDRESS ERROR ===');
      print('Error: $e');
      print('Stack trace: $stackTrace');
      print('=== END ERROR ===');
      
      // More specific error messages
      if (e.toString().contains('PERMISSION_DENIED')) {
        throw Exception('Permission denied. Check Firestore rules.');
      } else if (e.toString().contains('UNAVAILABLE')) {
        throw Exception('Network error. Please check your connection.');
      }
      
      rethrow;
    }
  }

  // Update address
  Future<void> updateAddress(Address address) async {
    try {
      print('=== UPDATE ADDRESS START ===');
      final userId = _userId;
      if (userId == null) throw Exception('User not authenticated');

      // Create updated address with current timestamp
      final updatedAddress = address.copyWith(
        userId: userId,
        updatedAt: DateTime.now(),
      );

      print('Updating address: ${updatedAddress.toMap()}');

      // If this address is set as primary, unset all other primary addresses
      if (updatedAddress.isPrimary) {
        await _unsetOtherPrimaryAddresses(userId, updatedAddress.id);
      }

      await _firestore
          .collection('users')
          .doc(userId)
          .collection('addresses')
          .doc(updatedAddress.id)
          .update(updatedAddress.toMap());

      print('=== UPDATE ADDRESS SUCCESS ===');
      
    } catch (e, stackTrace) {
      print('=== UPDATE ADDRESS ERROR ===');
      print('Error: $e');
      print('Stack trace: $stackTrace');
      rethrow;
    }
  }

  // Get all addresses for current user
  Future<List<Address>> getUserAddresses() async {
    try {
      final userId = _userId;
      if (userId == null) throw Exception('User not authenticated');

      final querySnapshot = await _firestore
          .collection('users')
          .doc(userId)
          .collection('addresses')
          .orderBy('updatedAt', descending: true)
          .get();

      print('Fetched ${querySnapshot.docs.length} addresses');
      
      return querySnapshot.docs
          .map((doc) => Address.fromFirestore(doc))
          .toList();

    } catch (e) {
      print('Error getting addresses: $e');
      return [];
    }
  }

  // Stream addresses for real-time updates
  Stream<List<Address>> getUserAddressesStream() {
    final userId = _userId;
    if (userId == null) {
      return Stream.value([]);
    }

    return _firestore
        .collection('users')
        .doc(userId)
        .collection('addresses')
        .orderBy('updatedAt', descending: true)
        .snapshots()
        .map((snapshot) {
          print('Stream update: ${snapshot.docs.length} addresses');
          return snapshot.docs.map((doc) => Address.fromFirestore(doc)).toList();
        })
        .handleError((error) {
          print('Error in addresses stream: $error');
          return [];
        });
  }

  // Get primary address
  Future<Address?> getPrimaryAddress() async {
    try {
      final addresses = await getUserAddresses();
      
      if (addresses.isEmpty) {
        return null; // No addresses exist
      }
      
      // Try to find primary address
      for (final address in addresses) {
        if (address.isPrimary) {
          return address;
        }
      }
      
      // If no primary found, return first address
      return addresses.first;
      
    } catch (e) {
      print('Error getting primary address: $e');
      return null;
    }
  }

  // Delete address
  Future<void> deleteAddress(String addressId) async {
    try {
      final userId = _userId;
      if (userId == null) throw Exception('User not authenticated');

      await _firestore
          .collection('users')
          .doc(userId)
          .collection('addresses')
          .doc(addressId)
          .delete();

      print('Deleted address: $addressId');
      
    } catch (e) {
      print('Error deleting address: $e');
      rethrow;
    }
  }

  // Private method to unset other primary addresses - FIXED VERSION
  Future<void> _unsetOtherPrimaryAddresses(String userId, String currentAddressId) async {
    try {
      // Get ALL addresses for this user first
      final querySnapshot = await _firestore
          .collection('users')
          .doc(userId)
          .collection('addresses')
          .get();

      final batch = _firestore.batch();
      int unsetCount = 0;
      
      // Filter and update client-side (no composite index needed)
      for (final doc in querySnapshot.docs) {
        final data = doc.data();
        final isPrimary = data['isPrimary'] ?? false;
        final addressId = data['id'] ?? doc.id;
        
        if (isPrimary == true && addressId != currentAddressId) {
          batch.update(doc.reference, {'isPrimary': false});
          unsetCount++;
        }
      }

      if (unsetCount > 0) {
        await batch.commit();
        print('Unset $unsetCount other primary addresses');
      }
    } catch (e, stackTrace) {
      print('Error unsetting other primary addresses: $e');
      print('Stack trace: $stackTrace');
      rethrow;
    }
  }

  // Get address by ID
  Future<Address?> getAddressById(String addressId) async {
    try {
      final userId = _userId;
      if (userId == null) throw Exception('User not authenticated');

      final doc = await _firestore
          .collection('users')
          .doc(userId)
          .collection('addresses')
          .doc(addressId)
          .get();

      if (doc.exists) {
        print('Found address by ID: $addressId');
        return Address.fromFirestore(doc);
      }
      
      print('Address not found: $addressId');
      return null;
      
    } catch (e) {
      print('Error getting address by ID: $e');
      return null;
    }
  }

  // Validate if user has at least one address for checkout
  Future<bool> validateCheckoutAddress() async {
    try {
      final hasAddress = await hasAddresses();
      if (!hasAddress) {
        print('No addresses found for checkout validation');
        return false;
      }

      final addresses = await getUserAddresses();
      if (addresses.isEmpty) {
        return false;
      }

      // Check if at least one address is complete and valid
      for (final address in addresses) {
        if (address.isValid) {
          return true;
        }
      }

      return false;
    } catch (e) {
      print('Error validating checkout address: $e');
      return false;
    }
  }

  // Test Firestore connection
  Future<void> testFirestoreConnection() async {
    try {
      final userId = _userId;
      print('Testing Firestore connection...');
      print('User ID: $userId');
      
      // Try to write a test document
      await _firestore
          .collection('test_connection')
          .doc('test_doc')
          .set({
            'test': 'test_value',
            'timestamp': FieldValue.serverTimestamp(),
            'userId': userId,
          });
      
      print('Firestore write test successful!');
      
      // Try to read
      final testDoc = await _firestore
          .collection('test_connection')
          .doc('test_doc')
          .get();
          
      if (testDoc.exists) {
        print('Firestore read test successful!');
      }
      
    } catch (e, stackTrace) {
      print('Firestore connection test failed: $e');
      print('Stack trace: $stackTrace');
      rethrow;
    }
  }
}