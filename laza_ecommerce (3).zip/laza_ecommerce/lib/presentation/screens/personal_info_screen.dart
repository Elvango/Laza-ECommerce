import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

String getDisplayName(String email) {
  if (email.isEmpty) return 'Guest';
  final name = email.split('@').first.replaceAll(RegExp(r'[0-9._]'), ' ');
  return name
      .split(' ')
      .where((e) => e.isNotEmpty)
      .map((e) => '${e[0].toUpperCase()}${e.substring(1)}')
      .join(' ');
}

class PersonalInfoScreen extends StatefulWidget {
  final User user;

  const PersonalInfoScreen({super.key, required this.user});

  @override
  State<PersonalInfoScreen> createState() => _PersonalInfoScreenState();
}

class _PersonalInfoScreenState extends State<PersonalInfoScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _emailController;
  late TextEditingController _phoneController;
  late TextEditingController _addressController;
  
  File? _profileImage;
  String? _profileImageUrl;
  bool _isLoading = false;
  bool _hasChanges = false;
  Map<String, dynamic> _originalData = {};

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final ImagePicker _imagePicker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
    _emailController = TextEditingController(text: widget.user.email);
    _phoneController = TextEditingController();
    _addressController = TextEditingController();
    
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    setState(() => _isLoading = true);
    
    try {
      final doc = await _firestore
          .collection('users')
          .doc(widget.user.uid)
          .get();
      
      if (doc.exists) {
        final data = doc.data()!;
        _originalData = Map.from(data);
        
        _nameController.text = data['name'] ?? getDisplayName(widget.user.email!);
        _phoneController.text = data['phone'] ?? '+1 (555) 123-4567';
        _addressController.text = data['address'] ?? '123 Main St, New York, NY 10001';
        _profileImageUrl = data['profileImageUrl'];
        
        // Initialize controllers with current values
        _nameController.addListener(_checkForChanges);
        _phoneController.addListener(_checkForChanges);
        _addressController.addListener(_checkForChanges);
      } else {
        // Create initial data if user doesn't exist in Firestore
        _nameController.text = getDisplayName(widget.user.email!);
        _phoneController.text = '+1 (555) 123-4567';
        _addressController.text = '123 Main St, New York, NY 10001';
        
        await _saveUserData(initialSave: true);
      }
    } catch (e) {
      print('Error loading user data: $e');
      _nameController.text = getDisplayName(widget.user.email!);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _checkForChanges() {
    final currentData = {
      'name': _nameController.text,
      'phone': _phoneController.text,
      'address': _addressController.text,
    };
    
    setState(() {
      _hasChanges = currentData['name'] != _originalData['name'] ||
          currentData['phone'] != _originalData['phone'] ||
          currentData['address'] != _originalData['address'] ||
          _profileImage != null;
    });
  }

  Future<void> _pickImage() async {
    final result = await showModalBottomSheet<dynamic>(
      context: context,
      backgroundColor: Colors.grey.shade900,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Colors.white),
              title: const Text('Take Photo', style: TextStyle(color: Colors.white)),
              onTap: () => Navigator.pop(context, 'camera'),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Colors.white),
              title: const Text('Choose from Gallery', style: TextStyle(color: Colors.white)),
              onTap: () => Navigator.pop(context, 'gallery'),
            ),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: Colors.grey.shade400)),
            ),
          ],
        ),
      ),
    );

    if (result == 'camera' || result == 'gallery') {
      try {
        final pickedFile = await _imagePicker.pickImage(
          source: result == 'camera' ? ImageSource.camera : ImageSource.gallery,
        );
        if (pickedFile != null) {
          setState(() {
            _profileImage = File(pickedFile.path);
            _hasChanges = true;
          });
        }
      } catch (e) {
        _showError('Failed to pick image: $e');
      }
    }
  }

  Future<String?> _uploadProfileImage() async {
    if (_profileImage == null) return null;
    
    try {
      final userId = widget.user.uid;
      final fileName = 'profile_$userId.jpg';
      final ref = _storage.ref().child('profile_images/$fileName');
      
      await ref.putFile(_profileImage!);
      return await ref.getDownloadURL();
    } catch (e) {
      _showError('Failed to upload image: $e');
      return null;
    }
  }

  Future<void> _saveUserData({bool initialSave = false}) async {
    if (!initialSave && !_hasChanges) return;
    
    if (!initialSave && !_formKey.currentState!.validate()) return;
    
    setState(() => _isLoading = true);
    
    try {
      String? newImageUrl;
      if (_profileImage != null) {
        newImageUrl = await _uploadProfileImage();
      }
      
      final userData = {
        'name': _nameController.text,
        'email': widget.user.email,
        'phone': _phoneController.text,
        'address': _addressController.text,
        'profileImageUrl': newImageUrl ?? _profileImageUrl,
        'updatedAt': FieldValue.serverTimestamp(),
        if (initialSave) 'createdAt': FieldValue.serverTimestamp(),
      };
      
      await _firestore
          .collection('users')
          .doc(widget.user.uid)
          .set(userData, SetOptions(merge: true));
      
      // Update user display name in Firebase Auth
      await widget.user.updateDisplayName(_nameController.text);
      
      // Update original data
      _originalData = Map.from(userData);
      if (newImageUrl != null) {
        _profileImageUrl = newImageUrl;
        _profileImage = null;
      }
      
      if (!initialSave) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Profile updated successfully'),
            backgroundColor: Colors.green.shade400,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
      
      setState(() => _hasChanges = false);
      
    } catch (e) {
      _showError('Failed to save: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red.shade400,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: CircularProgressIndicator(color: Colors.amberAccent),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            if (_hasChanges) {
              _showUnsavedChangesDialog();
            } else {
              Navigator.pop(context);
            }
          },
        ),
        title: const Text(
          'Personal Information',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          if (_hasChanges)
            IconButton(
              icon: const Icon(Icons.save, color: Colors.amberAccent),
              onPressed: () => _saveUserData(),
            ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Profile Picture
              Center(
                child: Stack(
                  children: [
                    Container(
                      width: 120,
                      height: 120,
                      decoration: BoxDecoration(
                        color: Colors.amberAccent,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.amberAccent.withOpacity(0.3),
                            blurRadius: 15,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: _profileImage != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(60),
                              child: Image.file(
                                _profileImage!,
                                fit: BoxFit.cover,
                                width: 120,
                                height: 120,
                              ),
                            )
                          : _profileImageUrl != null
                              ? ClipRRect(
                                  borderRadius: BorderRadius.circular(60),
                                  child: Image.network(
                                    _profileImageUrl!,
                                    fit: BoxFit.cover,
                                    width: 120,
                                    height: 120,
                                    errorBuilder: (context, error, stackTrace) => Center(
                                      child: Text(
                                        _nameController.text.isNotEmpty
                                            ? _nameController.text.substring(0, 2).toUpperCase()
                                            : 'GU',
                                        style: const TextStyle(
                                          color: Colors.black,
                                          fontSize: 36,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                              : Center(
                                  child: Text(
                                    _nameController.text.isNotEmpty
                                        ? _nameController.text.substring(0, 2).toUpperCase()
                                        : 'GU',
                                    style: const TextStyle(
                                      color: Colors.black,
                                      fontSize: 36,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade800,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.grey.shade700, width: 2),
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.camera_alt, size: 18),
                          color: Colors.grey.shade300,
                          onPressed: _pickImage,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 32),

              // Name Field
              Text(
                'Full Name',
                style: TextStyle(
                  color: Colors.grey.shade400,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _nameController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Enter your full name',
                  hintStyle: TextStyle(color: Colors.grey.shade600),
                  filled: true,
                  fillColor: Colors.grey.shade900,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  prefixIcon: Icon(Icons.person_outline, color: Colors.grey.shade400),
                  suffixIcon: _hasChanges && _nameController.text != _originalData['name']
                      ? const Icon(Icons.edit, color: Colors.amberAccent, size: 16)
                      : null,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your name';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),

              // Email Field (read-only)
              Text(
                'Email Address',
                style: TextStyle(
                  color: Colors.grey.shade400,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _emailController,
                style: TextStyle(color: Colors.grey.shade400),
                readOnly: true,
                decoration: InputDecoration(
                  hintText: 'Enter your email',
                  hintStyle: TextStyle(color: Colors.grey.shade600),
                  filled: true,
                  fillColor: Colors.grey.shade900.withOpacity(0.5),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  prefixIcon: Icon(Icons.email_outlined, color: Colors.grey.shade500),
                  suffixIcon: Icon(Icons.lock_outline, color: Colors.grey.shade500, size: 16), // Fixed: removed const
                ),
              ),
              const SizedBox(height: 20),

              // Phone Field
              Text(
                'Phone Number',
                style: TextStyle(
                  color: Colors.grey.shade400,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _phoneController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Enter your phone number',
                  hintStyle: TextStyle(color: Colors.grey.shade600),
                  filled: true,
                  fillColor: Colors.grey.shade900,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  prefixIcon: Icon(Icons.phone_outlined, color: Colors.grey.shade400),
                  suffixIcon: _hasChanges && _phoneController.text != _originalData['phone']
                      ? const Icon(Icons.edit, color: Colors.amberAccent, size: 16)
                      : null,
                ),
                keyboardType: TextInputType.phone,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your phone number';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),

              // Address Field
              Text(
                'Address',
                style: TextStyle(
                  color: Colors.grey.shade400,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _addressController,
                style: const TextStyle(color: Colors.white),
                maxLines: 3,
                decoration: InputDecoration(
                  hintText: 'Enter your address',
                  hintStyle: TextStyle(color: Colors.grey.shade600),
                  filled: true,
                  fillColor: Colors.grey.shade900,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  prefixIcon: Icon(Icons.location_on_outlined, color: Colors.grey.shade400),
                  suffixIcon: _hasChanges && _addressController.text != _originalData['address']
                      ? const Icon(Icons.edit, color: Colors.amberAccent, size: 16)
                      : null,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your address';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 40),

              // Save Button (only shows when there are changes)
              if (_hasChanges)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () => _saveUserData(),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.amberAccent,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.save, size: 20),
                        SizedBox(width: 8),
                        Text(
                          'Save Changes',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              if (_hasChanges) const SizedBox(height: 20),

              // Change Password Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/change-password');
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.grey.shade800,
                    foregroundColor: Colors.amberAccent,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(color: Colors.grey.shade700),
                    ),
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.lock_outline, size: 20),
                      SizedBox(width: 8),
                      Text(
                        'Change Password',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showUnsavedChangesDialog() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.grey.shade900,
          title: const Text(
            'Unsaved Changes',
            style: TextStyle(color: Colors.white),
          ),
          content: const Text(
            'You have unsaved changes. Are you sure you want to leave?',
            style: TextStyle(color: Colors.grey),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text(
                'Cancel',
                style: TextStyle(color: Colors.grey),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text(
                'Leave',
                style: TextStyle(color: Colors.red),
              ),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.pop(context);
              },
            ),
            TextButton(
              child: const Text(
                'Save & Exit',
                style: TextStyle(color: Colors.amberAccent),
              ),
              onPressed: () async {
                Navigator.of(context).pop();
                await _saveUserData();
                if (!_hasChanges) {
                  Navigator.pop(context);
                }
              },
            ),
          ],
        );
      },
    );
  }
}