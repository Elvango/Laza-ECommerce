// lib/presentation/screens/order_history_screen.dart
import 'package:flutter/material.dart';

class OrderHistoryScreen extends StatefulWidget {
  const OrderHistoryScreen({super.key});

  @override
  State<OrderHistoryScreen> createState() => _OrderHistoryScreenState();
}

class _OrderHistoryScreenState extends State<OrderHistoryScreen> {
  int _selectedFilter = 0; // 0: All, 1: Processing, 2: Delivered, 3: Cancelled

  final List<Map<String, dynamic>> _orders = [
    {
      'id': '#ORD-78945',
      'date': '15 Dec, 2023',
      'items': 3,
      'total': 299.97,
      'status': 'Delivered',
      'statusColor': Colors.green.shade400,
      'products': [
        {'name': 'Nike Air Max 270', 'color': 'Black', 'size': '10'},
        {'name': 'Adidas Ultraboost', 'color': 'White', 'size': '9'},
        {'name': 'Puma RS-X', 'color': 'Red', 'size': '10.5'},
      ],
    },
    {
      'id': '#ORD-78944',
      'date': '10 Dec, 2023',
      'items': 2,
      'total': 189.98,
      'status': 'Processing',
      'statusColor': Colors.amberAccent,
      'products': [
        {'name': 'Fila Disruptor II', 'color': 'White', 'size': '8'},
        {'name': 'Reebok Nano', 'color': 'Black', 'size': '9'},
      ],
    },
    {
      'id': '#ORD-78943',
      'date': '5 Dec, 2023',
      'items': 1,
      'total': 129.99,
      'status': 'Cancelled',
      'statusColor': Colors.redAccent,
      'products': [
        {'name': 'Nike Jordan 1', 'color': 'Red', 'size': '10'},
      ],
    },
    {
      'id': '#ORD-78942',
      'date': '1 Dec, 2023',
      'items': 4,
      'total': 459.96,
      'status': 'Delivered',
      'statusColor': Colors.green.shade400,
      'products': [
        {'name': 'Adidas NMD', 'color': 'Blue', 'size': '9.5'},
        {'name': 'Nike React', 'color': 'Gray', 'size': '10'},
        {'name': 'Puma Cali', 'color': 'Pink', 'size': '8'},
        {'name': 'Fila Ray', 'color': 'Green', 'size': '9'},
      ],
    },
  ];

  List<Map<String, dynamic>> get _filteredOrders {
    if (_selectedFilter == 0) return _orders;
    if (_selectedFilter == 1) {
      return _orders.where((order) => order['status'] == 'Processing').toList();
    }
    if (_selectedFilter == 2) {
      return _orders.where((order) => order['status'] == 'Delivered').toList();
    }
    if (_selectedFilter == 3) {
      return _orders.where((order) => order['status'] == 'Cancelled').toList();
    }
    return _orders;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Order History',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Column(
        children: [
          // Filter Chips
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildFilterChip('All', 0),
                  const SizedBox(width: 12),
                  _buildFilterChip('Processing', 1),
                  const SizedBox(width: 12),
                  _buildFilterChip('Delivered', 2),
                  const SizedBox(width: 12),
                  _buildFilterChip('Cancelled', 3),
                ],
              ),
            ),
          ),

          // Orders List
          Expanded(
            child: _filteredOrders.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.shopping_bag_outlined,
                          size: 80,
                          color: Colors.grey.shade800,
                        ),
                        const SizedBox(height: 20),
                        Text(
                          'No orders found',
                          style: TextStyle(
                            color: Colors.grey.shade400,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Your orders will appear here',
                          style: TextStyle(
                            color: Colors.grey.shade600,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                    itemCount: _filteredOrders.length,
                    itemBuilder: (context, index) {
                      final order = _filteredOrders[index];
                      return _buildOrderCard(order);
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String label, int index) {
    return ChoiceChip(
      label: Text(
        label,
        style: TextStyle(
          color: _selectedFilter == index ? Colors.black : Colors.white,
          fontWeight: FontWeight.w500,
        ),
      ),
      selected: _selectedFilter == index,
      selectedColor: Colors.amberAccent,
      backgroundColor: Colors.grey.shade900,
      side: BorderSide.none,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      onSelected: (selected) {
        setState(() {
          _selectedFilter = index;
        });
      },
    );
  }

  Widget _buildOrderCard(Map<String, dynamic> order) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade900,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Order Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    order['id'],
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    order['date'],
                    style: TextStyle(
                      color: Colors.grey.shade400,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: order['statusColor'].withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: order['statusColor'].withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Text(
                  order['status'],
                  style: TextStyle(
                    color: order['statusColor'],
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Order Items
          Column(
            children: List.generate(
              order['products'].length,
              (index) {
                final product = order['products'][index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Row(
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade800,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Center(
                          child: Icon(
                            Icons.shopping_bag_outlined,
                            color: Colors.grey.shade400,
                            size: 24,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              product['name'],
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              '${product['color']} • Size ${product['size']}',
                              style: TextStyle(
                                color: Colors.grey.shade400,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 16),

          // Order Footer
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${order['items']} item${order['items'] > 1 ? 's' : ''}',
                style: TextStyle(
                  color: Colors.grey.shade400,
                  fontSize: 14,
                ),
              ),
              Text(
                '\$${order['total'].toStringAsFixed(2)}',
                style: const TextStyle(
                  color: Colors.amberAccent,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Actions
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () {
                    // TODO: View order details
                  },
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.amberAccent,
                    side: BorderSide(color: Colors.grey.shade700),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text('View Details'),
                ),
              ),
              const SizedBox(width: 12),
              if (order['status'] == 'Delivered')
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      // TODO: Reorder
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.amberAccent,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text('Reorder'),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}