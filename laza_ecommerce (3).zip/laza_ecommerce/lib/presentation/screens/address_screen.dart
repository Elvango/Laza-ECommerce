import 'package:flutter/material.dart';
import 'package:laza_ecommerce/data/models/address_model.dart';
import 'package:laza_ecommerce/data/repositories/address_repository.dart';
import 'package:uuid/uuid.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AddressScreen extends StatefulWidget {
  final Address? existingAddress;
  final bool isCheckoutFlow;
  
  const AddressScreen({
    super.key, 
    this.existingAddress,
    this.isCheckoutFlow = false,
  });

  @override
  State<AddressScreen> createState() => _AddressScreenState();
}

class _AddressScreenState extends State<AddressScreen> {
  final _formKey = GlobalKey<FormState>();
  final AddressRepository _addressRepository = AddressRepository();
  final Uuid _uuid = const Uuid();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  
  // Controllers
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _countryController = TextEditingController();
  final TextEditingController _cityController = TextEditingController();
  final TextEditingController _stateController = TextEditingController();
  final TextEditingController _zipCodeController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _addressLine1Controller = TextEditingController();
  final TextEditingController _addressLine2Controller = TextEditingController();
  
  // Form values
  bool _saveAsPrimary = false;
  String _selectedLabel = 'Home';
  final List<String> _addressLabels = ['Home', 'Office', 'Other'];
  
  bool _isLoading = false;
  bool _isEditing = false;
  bool _isInitialized = false;
  bool _userLoggedIn = false;

  @override
  void initState() {
    super.initState();
    _checkUserAndInitialize();
  }

  void _checkUserAndInitialize() async {
    // Check if user is logged in
    final user = _auth.currentUser;
    
    if (user == null) {
      print('ERROR: No user logged in!');
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showErrorMessage('Please log in to save addresses');
        Future.delayed(const Duration(seconds: 2), () {
          if (mounted) Navigator.pop(context);
        });
      });
      return;
    }
    
    _userLoggedIn = true;
    print('User logged in: ${user.uid}');
    
    _isEditing = widget.existingAddress != null;
    
    if (_isEditing) {
      _loadExistingAddress(widget.existingAddress!);
    } else {
      // Check if this is the first address
      final hasAddresses = await _addressRepository.hasAddresses();
      _saveAsPrimary = !hasAddresses; // First address should be primary
    }
    
    setState(() {
      _isInitialized = true;
    });
  }

  void _loadExistingAddress(Address address) {
    _nameController.text = address.name;
    _countryController.text = address.country;
    _cityController.text = address.city;
    _stateController.text = address.state;
    _zipCodeController.text = address.zipCode;
    _phoneController.text = address.phone;
    _addressLine1Controller.text = address.addressLine1;
    _addressLine2Controller.text = address.addressLine2 ?? '';
    _saveAsPrimary = address.isPrimary;
    _selectedLabel = address.label;
  }

  Future<void> _saveAddress() async {
    // Validate form
    if (!_formKey.currentState!.validate()) {
      _showErrorMessage('Please fill all required fields correctly');
      return;
    }
    
    // Check user authentication
    final user = _auth.currentUser;
    if (user == null) {
      _showErrorMessage('Please log in to save addresses');
      return;
    }
    
    setState(() => _isLoading = true);
    
    try {
      print('=== SAVING ADDRESS ===');
      final now = DateTime.now();
      
      // Generate address ID
      String addressId;
      if (_isEditing && widget.existingAddress?.id != null) {
        addressId = widget.existingAddress!.id;
      } else {
        addressId = _uuid.v4();
      }

      // Create address object
      final address = Address(
        id: addressId,
        userId: user.uid,
        name: _nameController.text.trim(),
        country: _countryController.text.trim(),
        city: _cityController.text.trim(),
        state: _stateController.text.trim(),
        zipCode: _zipCodeController.text.trim(),
        phone: _phoneController.text.trim(),
        addressLine1: _addressLine1Controller.text.trim(),
        addressLine2: _addressLine2Controller.text.trim().isNotEmpty 
            ? _addressLine2Controller.text.trim() 
            : null,
        isPrimary: _saveAsPrimary,
        label: _selectedLabel,
        createdAt: widget.existingAddress?.createdAt ?? now,
        updatedAt: now,
      );

      print('Created address object: $address');
      print('Address fields:');
      print('- Name: ${address.name}');
      print('- Country: ${address.country}');
      print('- City: ${address.city}');
      print('- Address Line 1: ${address.addressLine1}');
      print('- Phone: ${address.phone}');
      print('- Is Primary: ${address.isPrimary}');

      // Save or update
      if (_isEditing) {
        print('Updating existing address...');
        await _addressRepository.updateAddress(address);
        _showSuccessMessage('Address updated successfully!');
      } else {
        print('Saving new address...');
        await _addressRepository.saveAddress(address);
        _showSuccessMessage('Address saved successfully!');
      }

      // Wait a moment for Firestore
      await Future.delayed(const Duration(milliseconds: 800));
      
      if (mounted) {
        Navigator.pop(context, {
          'address': address,
          'fromCheckout': widget.isCheckoutFlow,
        });
      }
      
    } catch (e) {
      print('Error in _saveAddress: $e');
      _showErrorMessage('Failed to save address: ${e.toString()}');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  // Test Firestore connection
  Future<void> _testFirestoreConnection() async {
    setState(() => _isLoading = true);
    try {
      await _addressRepository.testFirestoreConnection();
      _showSuccessMessage('Firestore connection successful!');
    } catch (e) {
      _showErrorMessage('Firestore test failed: $e');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _showSuccessMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _showErrorMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 4),
      ),
    );
  }

  // Helper method to build text fields
  Widget _buildTextField({
    required String label,
    required TextEditingController controller,
    required String hintText,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
    String? Function(String?)? validator,
    bool enabled = true,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: Colors.grey.shade300,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: Colors.grey.shade900,
            borderRadius: BorderRadius.circular(12),
          ),
          child: TextFormField(
            controller: controller,
            enabled: enabled,
            style: const TextStyle(color: Colors.white),
            keyboardType: keyboardType,
            maxLines: maxLines,
            decoration: InputDecoration(
              hintText: hintText,
              hintStyle: TextStyle(color: Colors.grey.shade500),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(16),
              errorStyle: const TextStyle(color: Colors.redAccent),
            ),
            validator: validator,
          ),
        ),
      ],
    );
  }

  // Phone validator
  String? _phoneValidator(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter phone number';
    }
    
    // Basic phone validation
    final phoneRegex = RegExp(r'^[+0-9][0-9\s\-]{9,}$');
    if (!phoneRegex.hasMatch(value)) {
      return 'Please enter a valid phone number';
    }
    
    return null;
  }

  // ZIP code validator
  String? _zipCodeValidator(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter ZIP code';
    }
    
    if (value.length < 4) {
      return 'Please enter a valid ZIP code';
    }
    
    return null;
  }

  @override
  Widget build(BuildContext context) {
    if (!_userLoggedIn) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, color: Colors.red, size: 64),
              const SizedBox(height: 20),
              Text(
                'User not logged in',
                style: TextStyle(
                  color: Colors.grey.shade300,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Please log in to save addresses',
                style: TextStyle(
                  color: Colors.grey.shade500,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.amberAccent,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                ),
                child: const Text('Go Back'),
              ),
            ],
          ),
        ),
      );
    }

    if (!_isInitialized) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: const Center(
          child: CircularProgressIndicator(color: Colors.amberAccent),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEditing ? 'Edit Address' : 'Add Shipping Address',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: _isLoading
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(
                    color: Colors.amberAccent,
                  ),
                  SizedBox(height: 20),
                  Text(
                    'Saving address...',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (widget.isCheckoutFlow) ...[
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.amber.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.amber, width: 1),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.info_outline, color: Colors.amber.shade300),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'Shipping address is required to proceed with checkout',
                              style: TextStyle(
                                color: Colors.amber.shade300,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                  
                  // Debug info
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade900,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.info,
                          color: Colors.blue.shade300,
                          size: 20,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            _isEditing 
                                ? 'Editing address: ${widget.existingAddress?.name}'
                                : 'Creating new address',
                            style: TextStyle(
                              color: Colors.blue.shade300,
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  
                  Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Full Name
                        _buildTextField(
                          label: 'Full Name *',
                          controller: _nameController,
                          hintText: 'Enter your full name',
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your name';
                            }
                            return null;
                          },
                        ),

                        const SizedBox(height: 20),

                        // Country and City Row
                        Row(
                          children: [
                            Expanded(
                              child: _buildTextField(
                                label: 'Country *',
                                controller: _countryController,
                                hintText: 'Enter country',
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please enter country';
                                  }
                                    return null;
                                },
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: _buildTextField(
                                label: 'City *',
                                controller: _cityController,
                                hintText: 'Enter city',
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please enter city';
                                  }
                                  return null;
                                },
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 20),

                        // State and ZIP Code Row
                        Row(
                          children: [
                            Expanded(
                              child: _buildTextField(
                                label: 'State/Province *',
                                controller: _stateController,
                                hintText: 'Enter state',
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please enter state';
                                  }
                                  return null;
                                },
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: _buildTextField(
                                label: 'ZIP/Postal Code *',
                                controller: _zipCodeController,
                                hintText: 'Enter ZIP code',
                                keyboardType: TextInputType.number,
                                validator: _zipCodeValidator,
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 20),

                        // Phone Number
                        _buildTextField(
                          label: 'Phone Number *',
                          controller: _phoneController,
                          hintText: '+1 (555) 123-4567',
                          keyboardType: TextInputType.phone,
                          validator: _phoneValidator,
                        ),

                        const SizedBox(height: 20),

                        // Address Line 1
                        _buildTextField(
                          label: 'Street Address *',
                          controller: _addressLine1Controller,
                          hintText: 'House number, street name',
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter street address';
                            }
                            return null;
                          },
                        ),

                        const SizedBox(height: 20),

                        // Address Line 2 (Optional)
                        _buildTextField(
                          label: 'Apartment, Suite, etc. (Optional)',
                          controller: _addressLine2Controller,
                          hintText: 'Apartment, suite, unit, building, floor',
                        ),

                        const SizedBox(height: 24),

                        // Address Label
                        Text(
                          'Address Label',
                          style: TextStyle(
                            color: Colors.grey.shade300,
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 8),
                        SizedBox(
                          height: 50,
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: _addressLabels.length,
                            itemBuilder: (context, index) {
                              final label = _addressLabels[index];
                              final isSelected = _selectedLabel == label;
                              
                              return Padding(
                                padding: EdgeInsets.only(
                                  right: index < _addressLabels.length - 1 ? 12 : 0,
                                ),
                                child: ChoiceChip(
                                  label: Text(
                                    label,
                                    style: TextStyle(
                                      color: isSelected ? Colors.black : Colors.white,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  selected: isSelected,
                                  selectedColor: Colors.amberAccent,
                                  backgroundColor: Colors.grey.shade900,
                                  side: BorderSide.none,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                                  onSelected: (selected) {
                                    if (selected) {
                                      setState(() {
                                        _selectedLabel = label;
                                      });
                                    }
                                  },
                                ),
                              );
                            },
                          ),
                        ),

                        const SizedBox(height: 24),

                        // Save as primary address
                        Row(
                          children: [
                            Transform.scale(
                              scale: 1.2,
                              child: Checkbox(
                                value: _saveAsPrimary,
                                onChanged: (value) {
                                  setState(() {
                                    _saveAsPrimary = value ?? false;
                                  });
                                },
                                activeColor: Colors.amberAccent,
                                checkColor: Colors.black,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'Set as primary shipping address',
                              style: TextStyle(
                                color: Colors.grey.shade300,
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 30),

                        // Debug button (remove in production)
                        if (!_isEditing) // Only show for new addresses
                        Column(
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                onPressed: _testFirestoreConnection,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.blue.shade800,
                                  foregroundColor: Colors.white,
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                                child: const Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.wifi_tethering, size: 20),
                                    SizedBox(width: 10),
                                    Text('Test Firestore Connection'),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(height: 20),
                            const Divider(color: Colors.grey),
                            const SizedBox(height: 20),
                          ],
                        ),

                        // Save Address Button
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: _isLoading ? null : _saveAddress,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.amberAccent,
                              foregroundColor: Colors.black,
                              padding: const EdgeInsets.symmetric(vertical: 18),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              disabledBackgroundColor: Colors.grey.shade700,
                            ),
                            child: _isLoading
                                ? const SizedBox(
                                    height: 24,
                                    width: 24,
                                    child: CircularProgressIndicator(
                                      color: Colors.black,
                                      strokeWidth: 2,
                                    ),
                                  )
                                : Text(
                                    _isEditing 
                                      ? 'Update Address' 
                                      : widget.isCheckoutFlow
                                        ? 'Save & Continue to Checkout'
                                        : 'Save Address',
                                    style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                          ),
                        ),
                        
                        const SizedBox(height: 30),
                        
                        // User info
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade900.withOpacity(0.5),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.account_circle,
                                color: Colors.grey.shade400,
                                size: 20,
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  'User: ${_auth.currentUser?.email ?? _auth.currentUser?.uid}',
                                  style: TextStyle(
                                    color: Colors.grey.shade400,
                                    fontSize: 12,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _countryController.dispose();
    _cityController.dispose();
    _stateController.dispose();
    _zipCodeController.dispose();
    _phoneController.dispose();
    _addressLine1Controller.dispose();
    _addressLine2Controller.dispose();
    super.dispose();
  }
}