import 'package:flutter/material.dart';
import '../../data/repositories/cart_repository.dart';

class OrderConfirmedScreen extends StatefulWidget {
  final Map<String, dynamic>? orderData;

  const OrderConfirmedScreen({super.key, this.orderData});

  @override
  State<OrderConfirmedScreen> createState() => _OrderConfirmedScreenState();
}

class _OrderConfirmedScreenState extends State<OrderConfirmedScreen> {
  final CartRepository _cartRepo = CartRepository();
  bool _cartCleared = false;

  @override
  void initState() {
    super.initState();
    _clearCart();
  }

  Future<void> _clearCart() async {
    if (!_cartCleared) {
      try {
        await _cartRepo.clearCart();
        _cartCleared = true;
        print('Cart cleared successfully after order confirmation');
      } catch (e) {
        print('Error clearing cart: $e');
      }
    }
  }

  // Helper method to safely extract total amount with null safety
  double _getTotalAmount() {
    if (widget.orderData == null) return 140.0;
    
    final total = widget.orderData?['total'];
    
    // Handle different possible types
    if (total is double) return total;
    if (total is int) return total.toDouble();
    if (total is String) {
      return double.tryParse(total) ?? 140.0;
    }
    
    return 140.0; // Default fallback
  }

  @override
  Widget build(BuildContext context) {
    // Generate a unique order ID
    final orderId = widget.orderData?['orderId'] ?? 
        '#${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}';
    
    // Safely get total amount with null safety
    final totalAmount = _getTotalAmount();
    
    // Format dates
    final now = DateTime.now();
    final date = widget.orderData?['date'] ?? 
        '${now.day}/${now.month}/${now.year}';
    
    final deliveryDate = now.add(const Duration(days: 7));
    final formattedDeliveryDate = 
        '${deliveryDate.day}/${deliveryDate.month}/${deliveryDate.year}';
    
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 20),

              // Success Animation
              _buildSuccessAnimation(),

              const SizedBox(height: 32),

              // Success Message
              const Text(
                'Order Confirmed!',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 16),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    Text(
                      'Your order has been confirmed, we will send you confirmation email shortly.',
                      style: TextStyle(
                        color: Colors.grey.shade400,
                        fontSize: 16,
                        height: 1.5,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                    if (_cartCleared)
                      Text(
                        'Your cart has been cleared.',
                        style: TextStyle(
                          color: Colors.green.shade400,
                          fontSize: 14,
                          fontStyle: FontStyle.italic,
                        ),
                        textAlign: TextAlign.center,
                      ),
                  ],
                ),
              ),

              const SizedBox(height: 48),

              // Order Details Card
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.grey.shade900,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 15,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    _buildDetailRow('Order ID', orderId),
                    const SizedBox(height: 20),
                    const Divider(color: Colors.grey, height: 1),
                    const SizedBox(height: 20),
                    _buildDetailRow('Date', date),
                    const SizedBox(height: 20),
                    const Divider(color: Colors.grey, height: 1),
                    const SizedBox(height: 20),
                    _buildDetailRow('Estimated Delivery', formattedDeliveryDate),
                    const SizedBox(height: 20),
                    const Divider(color: Colors.grey, height: 1),
                    const SizedBox(height: 20),
                    _buildDetailRow(
                      'Total Amount',
                      '\$${totalAmount.toStringAsFixed(2)}',
                      isHighlighted: true,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 40),

              // Action Buttons
              Column(
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pushNamedAndRemoveUntil(
                          context,
                          '/home',
                          (route) => false,
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.amberAccent,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 4,
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.shopping_bag_outlined, size: 22),
                          SizedBox(width: 12),
                          Text(
                            'Continue Shopping',
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: const Text('Orders screen coming soon!'),
                            backgroundColor: Colors.amberAccent,
                            behavior: SnackBarBehavior.floating,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            duration: const Duration(seconds: 2),
                          ),
                        );
                      },
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.amberAccent,
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        side: const BorderSide(
                          color: Colors.amberAccent,
                          width: 2,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.receipt_long_outlined, size: 22),
                          SizedBox(width: 12),
                          Text(
                            'View Order Details',
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 30),

              // Help Text
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.info_outline,
                    color: Colors.amberAccent.withOpacity(0.8),
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: const Row(
                            children: [
                              Icon(Icons.email, color: Colors.white, size: 20),
                              SizedBox(width: 10),
                              Text('support@laza.com'),
                            ],
                          ),
                          backgroundColor: Colors.grey.shade800,
                          behavior: SnackBarBehavior.floating,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          duration: const Duration(seconds: 3),
                        ),
                      );
                    },
                    child: Text(
                      'Need help? Contact Support',
                      style: TextStyle(
                        color: Colors.amberAccent,
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSuccessAnimation() {
    return Stack(
      alignment: Alignment.center,
      children: [
        // Outer glow
        Container(
          width: 180,
          height: 180,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              colors: [
                Colors.green.withOpacity(0.2),
                Colors.green.withOpacity(0.05),
              ],
            ),
          ),
        ),
        
        // Animated circles
        for (int i = 0; i < 3; i++)
          Container(
            width: 160 - (i * 40),
            height: 160 - (i * 40),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.green.withOpacity(0.3 - (i * 0.1)),
                width: 1.5,
              ),
            ),
          ),
        
        // Main circle
        Container(
          width: 120,
          height: 120,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.green.shade700,
                Colors.green.shade500,
              ],
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.green.withOpacity(0.4),
                blurRadius: 20,
                spreadRadius: 5,
              ),
            ],
          ),
          child: const Icon(
            Icons.check,
            color: Colors.white,
            size: 60,
            weight: 2,
          ),
        ),
        
        // Small checkmark
        Positioned(
          right: 40,
          bottom: 40,
          child: Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.green.shade400,
            ),
            child: const Icon(
              Icons.check,
              color: Colors.white,
              size: 18,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDetailRow(String label, String value, {bool isHighlighted = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            color: isHighlighted ? Colors.amberAccent : Colors.grey.shade300,
            fontSize: isHighlighted ? 17 : 15,
            fontWeight: isHighlighted ? FontWeight.w600 : FontWeight.normal,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            color: isHighlighted ? Colors.amberAccent : Colors.white,
            fontSize: isHighlighted ? 19 : 16,
            fontWeight: isHighlighted ? FontWeight.bold : FontWeight.w600,
          ),
        ),
      ],
    );
  }
}