import 'package:flutter/material.dart';
import '../../data/models/cart_item_model.dart';
import '../../data/models/address_model.dart';
import '../../data/models/card_model.dart';

class PaymentScreen extends StatefulWidget {
  final List<CartItem> cartItems;
  final double totalAmount;
  final Address shippingAddress;
  final CardModel? selectedCard;

  const PaymentScreen({
    super.key,
    required this.cartItems,
    required this.totalAmount,
    required this.shippingAddress,
    this.selectedCard,
  });

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _cardNumberController = TextEditingController();
  final TextEditingController _expiryController = TextEditingController();
  final TextEditingController _cvvController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();

  bool _isProcessing = false;
  double _shippingCost = 5.99;
  double _taxRate = 0.08;
  bool _useSavedCard = true;

  double get _finalTotal => widget.totalAmount + _shippingCost + (widget.totalAmount * _taxRate);

  @override
  void initState() {
    super.initState();
    
    if (widget.selectedCard != null) {
      _useSavedCard = true;
      _cardNumberController.text = widget.selectedCard!.fullMaskedCardNumber;
      _expiryController.text = widget.selectedCard!.expiryMonth.padLeft(2, '0') + '/' + widget.selectedCard!.expiryYear.substring(2);
      _nameController.text = widget.selectedCard!.cardHolderName;
    }
  }

  void _processPayment() async {
    // Validate form if using new card
    if (!_useSavedCard && !_formKey.currentState!.validate()) return;
    
    // Always require CVV validation
    if (_cvvController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please enter CVV'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() => _isProcessing = true);

    // Mock delay to simulate payment processing
    await Future.delayed(const Duration(seconds: 2));

    setState(() => _isProcessing = false);

    // Prepare payment method display
    String paymentMethodDisplay;
    String lastFourDigits;
    
    if (_useSavedCard && widget.selectedCard != null) {
      lastFourDigits = widget.selectedCard!.cardNumber.length >= 4 
          ? widget.selectedCard!.cardNumber.substring(widget.selectedCard!.cardNumber.length - 4)
          : '****';
      paymentMethodDisplay = '${widget.selectedCard!.cardType} ****$lastFourDigits';
    } else {
      final cardNumber = _cardNumberController.text.replaceAll(RegExp(r'[^0-9]'), '');
      lastFourDigits = cardNumber.length >= 4 
          ? cardNumber.substring(cardNumber.length - 4)
          : '****';
      paymentMethodDisplay = 'Credit Card ****$lastFourDigits';
    }

    // Generate order ID
    final orderId = '#${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}';

    // Navigate to success page with all details
    Navigator.pushNamedAndRemoveUntil(
      context,
      '/payment-success',
      (route) => false,
      arguments: {
        'items': widget.cartItems.map((e) {
          final price = e.price ?? 0.0;
          final quantity = e.quantity;
          return {
            'productId': e.productId,
            'title': e.title,
            'image': e.image,
            'price': price,
            'quantity': quantity,
            'size': e.size,
            'total': price * quantity,
          };
        }).toList(),
        'totalAmount': widget.totalAmount,
        'shippingCost': _shippingCost,
        'tax': widget.totalAmount * _taxRate,
        'finalTotal': _finalTotal,
        'shippingAddress': widget.shippingAddress.toMap(), // Use toMap() instead of toSimpleMap()
        'paymentMethod': paymentMethodDisplay,
        'orderId': orderId,
      },
    );
  }

  Widget _buildOrderSummary() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade900,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade800, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Order Summary',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          
          _buildSummaryRow(
            label: 'Subtotal',
            value: '\$${widget.totalAmount.toStringAsFixed(2)}',
          ),
          
          _buildSummaryRow(
            label: 'Shipping',
            value: '\$${_shippingCost.toStringAsFixed(2)}',
          ),
          
          _buildSummaryRow(
            label: 'Tax (8%)',
            value: '\$${(widget.totalAmount * _taxRate).toStringAsFixed(2)}',
          ),
          
          const Divider(color: Colors.grey, height: 24),
          
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Total',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                '\$${_finalTotal.toStringAsFixed(2)}',
                style: const TextStyle(
                  color: Colors.amberAccent,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryRow({
    required String label,
    required String value,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(color: Colors.grey.shade300),
          ),
          Text(
            value,
            style: const TextStyle(
              color: Colors.amberAccent,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildShippingInfo() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade900,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade800, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.location_on, color: Colors.amberAccent, size: 20),
              const SizedBox(width: 8),
              const Text(
                'Shipping to',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            widget.shippingAddress.name,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            widget.shippingAddress.formattedAddress,
            style: TextStyle(color: Colors.grey.shade400),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 4),
          Text(
            widget.shippingAddress.phone,
            style: TextStyle(color: Colors.grey.shade400),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.amberAccent.withOpacity(0.2),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              widget.shippingAddress.label,
              style: TextStyle(
                color: Colors.amberAccent,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentMethodSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade900,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade800, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Payment Method',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          
          if (widget.selectedCard != null) ...[
            Card(
              color: Colors.grey.shade800,
              margin: EdgeInsets.zero,
              child: ListTile(
                contentPadding: const EdgeInsets.all(12),
                leading: Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: _getCardColor(widget.selectedCard!.cardType),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.credit_card,
                    color: Colors.white,
                    size: 28,
                  ),
                ),
                title: Text(
                  widget.selectedCard!.fullMaskedCardNumber,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 4),
                    Text(
                      widget.selectedCard!.cardHolderName,
                      style: TextStyle(color: Colors.grey.shade300),
                    ),
                    Text(
                      'Expires: ${widget.selectedCard!.expiryMonth.padLeft(2, '0')}/${widget.selectedCard!.expiryYear.substring(2)}',
                      style: TextStyle(color: Colors.grey.shade300),
                    ),
                  ],
                ),
                trailing: Radio<bool>(
                  value: true,
                  groupValue: _useSavedCard,
                  onChanged: (value) {
                    setState(() {
                      _useSavedCard = value ?? true;
                    });
                  },
                  activeColor: Colors.amberAccent,
                ),
                onTap: () {
                  setState(() {
                    _useSavedCard = true;
                  });
                },
              ),
            ),
            
            const SizedBox(height: 16),
            
            Row(
              children: [
                Expanded(
                  child: Divider(color: Colors.grey.shade600, thickness: 1),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    'OR',
                    style: TextStyle(
                      color: Colors.grey.shade400,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Expanded(
                  child: Divider(color: Colors.grey.shade600, thickness: 1),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
          ],
          
          Card(
            color: Colors.grey.shade800,
            margin: EdgeInsets.zero,
            child: ListTile(
              contentPadding: const EdgeInsets.all(12),
              leading: Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: Colors.grey.shade700,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  Icons.add_card,
                  color: Colors.amberAccent,
                  size: 28,
                ),
              ),
              title: const Text(
                'Use Different Card',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              subtitle: const Text(
                'Enter new card details',
                style: TextStyle(color: Colors.grey),
              ),
              trailing: Radio<bool>(
                value: false,
                groupValue: _useSavedCard,
                onChanged: (value) {
                  setState(() {
                    _useSavedCard = false;
                  });
                },
                activeColor: Colors.amberAccent,
              ),
              onTap: () {
                setState(() {
                  _useSavedCard = false;
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  Color _getCardColor(String cardType) {
    switch (cardType.toLowerCase()) {
      case 'visa':
        return Colors.blue;
      case 'mastercard':
        return Colors.red;
      case 'amex':
        return Colors.green;
      case 'discover':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  Widget _buildTextField({
    required String label,
    required TextEditingController controller,
    required String hintText,
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
    bool obscureText = false,
    bool enabled = true,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: Colors.grey.shade300,
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: enabled ? Colors.grey.shade900 : Colors.grey.shade800,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: enabled ? Colors.grey.shade800 : Colors.grey.shade700,
              width: 1,
            ),
          ),
          child: TextFormField(
            controller: controller,
            keyboardType: keyboardType,
            obscureText: obscureText,
            enabled: enabled,
            style: TextStyle(
              color: enabled ? Colors.white : Colors.grey.shade400,
            ),
            decoration: InputDecoration(
              hintText: hintText,
              hintStyle: TextStyle(color: Colors.grey.shade500),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(16),
              errorStyle: const TextStyle(color: Colors.redAccent),
            ),
            validator: enabled ? validator : null,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        title: const Text(
          'Payment',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildOrderSummary(),
            
            const SizedBox(height: 24),
            
            _buildShippingInfo(),
            
            const SizedBox(height: 24),
            
            _buildPaymentMethodSection(),
            
            if (!_useSavedCard) ...[
              const SizedBox(height: 24),
              
              Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Enter Card Details',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    
                    _buildTextField(
                      label: 'Card Number',
                      controller: _cardNumberController,
                      hintText: '1234 5678 9012 3456',
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter card number';
                        }
                        final cardNumber = value.replaceAll(RegExp(r'\s+'), '');
                        if (cardNumber.length < 16) {
                          return 'Enter valid 16-digit card number';
                        }
                        return null;
                      },
                    ),
                    
                    const SizedBox(height: 16),
                    
                    Row(
                      children: [
                        Expanded(
                          child: _buildTextField(
                            label: 'Expiry Date',
                            controller: _expiryController,
                            hintText: 'MM/YY',
                            keyboardType: TextInputType.datetime,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter expiry date';
                              }
                              final expiryRegex = RegExp(r'^(0[1-9]|1[0-2])\/([0-9]{2})$');
                              if (!expiryRegex.hasMatch(value)) {
                                return 'Enter valid MM/YY format';
                              }
                              return null;
                            },
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: _buildTextField(
                            label: 'CVV',
                            controller: _cvvController,
                            hintText: '123',
                            keyboardType: TextInputType.number,
                            obscureText: true,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter CVV';
                              }
                              if (value.length < 3) {
                                return 'Enter valid 3-digit CVV';
                              }
                              return null;
                            },
                          ),
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 16),
                    
                    _buildTextField(
                      label: 'Cardholder Name',
                      controller: _nameController,
                      hintText: 'John Doe',
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter cardholder name';
                        }
                        return null;
                      },
                    ),
                    
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            ] else if (widget.selectedCard != null) ...[
              const SizedBox(height: 24),
              _buildTextField(
                label: 'CVV for ${widget.selectedCard!.fullMaskedCardNumber}',
                controller: _cvvController,
                hintText: '123',
                keyboardType: TextInputType.number,
                obscureText: true,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter CVV for verification';
                  }
                  if (value.length < 3) {
                    return 'Enter valid 3-digit CVV';
                  }
                  return null;
                },
              ),
            ],
            
            const SizedBox(height: 32),
            
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isProcessing ? null : _processPayment,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.amberAccent,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 18),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  disabledBackgroundColor: Colors.grey.shade700,
                ),
                child: _isProcessing
                    ? const SizedBox(
                        height: 24,
                        width: 24,
                        child: CircularProgressIndicator(
                          color: Colors.black,
                          strokeWidth: 2,
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.lock, size: 20),
                          const SizedBox(width: 8),
                          Text(
                            'Pay \$${_finalTotal.toStringAsFixed(2)}',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
            
            const SizedBox(height: 16),
            
            Row(
              children: [
                Icon(Icons.lock_outline, color: Colors.green.shade400, size: 16),
                const SizedBox(width: 8),
                Text(
                  'Your payment is secured with SSL encryption',
                  style: TextStyle(
                    color: Colors.green.shade400,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}