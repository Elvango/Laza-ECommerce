import 'package:flutter/material.dart';
import '../../data/models/address_model.dart';
import 'package:intl/intl.dart';

class PaymentSuccessScreen extends StatelessWidget {
  final Map<String, dynamic>? orderData;

  const PaymentSuccessScreen({super.key, this.orderData});

  @override
  Widget build(BuildContext context) {
    // If no orderData passed via constructor, try to get from route arguments
    final Map<String, dynamic> arguments = orderData ?? 
        (ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?) ?? {};

    // Extract all arguments with null safety
    final List<dynamic>? rawItems = arguments['items'];
    
    // Extract numeric values with null safety
    final totalAmount = _parseDouble(arguments['totalAmount']) ?? 0.0;
    final shippingCost = _parseDouble(arguments['shippingCost']) ?? 5.99;
    final tax = _parseDouble(arguments['tax']) ?? (totalAmount * 0.08);
    final finalTotal = _parseDouble(arguments['finalTotal']) ?? (totalAmount + shippingCost + tax);
    
    // Handle shipping address
    Address? shippingAddress;
    if (arguments['shippingAddress'] != null) {
      try {
        if (arguments['shippingAddress'] is Map<String, dynamic>) {
          shippingAddress = Address.fromMap(arguments['shippingAddress'] as Map<String, dynamic>);
        } else {
          shippingAddress = null;
        }
      } catch (e) {
        print('Error parsing shipping address: $e');
        shippingAddress = null;
      }
    } else {
      shippingAddress = null;
    }
    
    final String paymentMethod = arguments['paymentMethod']?.toString() ?? 'Credit Card';
    final String orderId = arguments['orderId']?.toString() ?? 
        '#${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}';

    // Format date
    final formattedDate = DateFormat('MMM dd, yyyy - hh:mm a').format(DateTime.now());
    
    // Calculate delivery date (3-5 days from now)
    final deliveryDate = DateTime.now().add(const Duration(days: 3));
    final formattedDeliveryDate = DateFormat('MMM dd, yyyy').format(deliveryDate);

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Success Icon
              Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  color: Colors.green.shade900.withOpacity(0.2),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.green, width: 2),
                ),
                child: const Icon(
                  Icons.check,
                  color: Colors.green,
                  size: 60,
                ),
              ),
              
              const SizedBox(height: 24),
              
              // Success Message
              const Text(
                'Payment Successful!',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              
              const SizedBox(height: 8),
              
              Text(
                'Your order has been confirmed',
                style: TextStyle(
                  color: Colors.grey.shade400,
                  fontSize: 16,
                ),
              ),
              
              const SizedBox(height: 32),
              
              // Order Details Card
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.grey.shade900,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Order Number
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Order Number',
                          style: TextStyle(
                            color: Colors.grey,
                            fontSize: 14,
                          ),
                        ),
                        Text(
                          orderId,
                          style: const TextStyle(
                            color: Colors.amberAccent,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // Date
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Date',
                          style: TextStyle(
                            color: Colors.grey,
                            fontSize: 14,
                          ),
                        ),
                        Text(
                          formattedDate,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // Payment Method
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Payment Method',
                          style: TextStyle(
                            color: Colors.grey,
                            fontSize: 14,
                          ),
                        ),
                        Row(
                          children: [
                            Icon(
                              _getPaymentMethodIcon(paymentMethod),
                              color: Colors.white,
                              size: 16,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              paymentMethod,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    
                    const Divider(color: Colors.grey, height: 32),
                    
                    // Order Summary
                    const Text(
                      'Order Summary',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // Items List (simplified since we don't have full item data)
                    if (rawItems != null && rawItems.isNotEmpty)
                      Column(
                        children: rawItems.take(3).map((item) {
                          final Map<String, dynamic> itemMap = item is Map<String, dynamic> ? item : {};
                          final title = itemMap['title']?.toString() ?? 'Product';
                          final quantity = _parseInt(itemMap['quantity']) ?? 1;
                          final price = _parseDouble(itemMap['price']) ?? _parseDouble(itemMap['total']) ?? 0.0;
                          final total = price * quantity;
                          
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        title,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 14,
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        '$quantity x \$${price.toStringAsFixed(2)}',
                                        style: TextStyle(
                                          color: Colors.grey.shade400,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Text(
                                  '\$${total.toStringAsFixed(2)}',
                                  style: const TextStyle(
                                    color: Colors.amberAccent,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                      )
                    else
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Text(
                          'Items: ${rawItems?.length ?? 0}',
                          style: const TextStyle(
                            color: Colors.grey,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    
                    const Divider(color: Colors.grey, height: 32),
                    
                    // Price Breakdown
                    _buildPriceRow(
                      label: 'Subtotal',
                      value: '\$${totalAmount.toStringAsFixed(2)}',
                    ),
                    
                    _buildPriceRow(
                      label: 'Shipping',
                      value: '\$${shippingCost.toStringAsFixed(2)}',
                    ),
                    
                    _buildPriceRow(
                      label: 'Tax',
                      value: '\$${tax.toStringAsFixed(2)}',
                    ),
                    
                    const Divider(color: Colors.grey, height: 24),
                    
                    // Total
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Total',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          '\$${finalTotal.toStringAsFixed(2)}',
                          style: const TextStyle(
                            color: Colors.amberAccent,
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 24),
              
              // Shipping Address Card (only if address exists)
              if (shippingAddress != null)
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade900,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.location_on, color: Colors.amberAccent, size: 20),
                          const SizedBox(width: 8),
                          const Text(
                            'Shipping Address',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Address Details
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            shippingAddress.name,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          
                          const SizedBox(height: 8),
                          
                          Text(
                            shippingAddress.addressLine1,
                            style: TextStyle(
                              color: Colors.grey.shade400,
                            ),
                          ),
                          
                          if (shippingAddress.addressLine2 != null && shippingAddress.addressLine2!.isNotEmpty)
                            Column(
                              children: [
                                const SizedBox(height: 4),
                                Text(
                                  shippingAddress.addressLine2!,
                                  style: TextStyle(
                                    color: Colors.grey.shade400,
                                  ),
                                ),
                              ],
                            ),
                          
                          const SizedBox(height: 4),
                          
                          Text(
                            '${shippingAddress.city}, ${shippingAddress.state} ${shippingAddress.zipCode}',
                            style: TextStyle(
                              color: Colors.grey.shade400,
                            ),
                          ),
                          
                          const SizedBox(height: 4),
                          
                          Text(
                            shippingAddress.country,
                            style: TextStyle(
                              color: Colors.grey.shade400,
                            ),
                          ),
                          
                          const SizedBox(height: 4),
                          
                          Text(
                            shippingAddress.phone,
                            style: TextStyle(
                              color: Colors.grey.shade400,
                            ),
                          ),
                          
                          const SizedBox(height: 12),
                          
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: shippingAddress.isPrimary 
                                  ? Colors.amberAccent.withOpacity(0.2)
                                  : Colors.grey.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  shippingAddress.isPrimary ? Icons.star : Icons.location_pin,
                                  color: shippingAddress.isPrimary ? Colors.amberAccent : Colors.grey,
                                  size: 14,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  shippingAddress.label,
                                  style: TextStyle(
                                    color: shippingAddress.isPrimary ? Colors.amberAccent : Colors.grey,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              
              const SizedBox(height: 32),
              
              // Delivery Estimate
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.grey.shade900,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    Icon(Icons.local_shipping, color: Colors.amberAccent, size: 24),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Estimated Delivery',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '3-5 business days (by $formattedDeliveryDate)',
                            style: TextStyle(
                              color: Colors.grey.shade400,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 32),
              
              // Action Buttons
              Column(
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to home screen
                        Navigator.pushNamedAndRemoveUntil(
                          context, 
                          '/home', 
                          (route) => false,
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.amberAccent,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      child: const Text(
                        'Continue Shopping',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 16),
                  
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () {
                        // View order details or tracking
                        // Navigator.pushNamed(context, '/order-tracking');
                      },
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: Colors.amberAccent),
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      child: const Text(
                        'Track Order',
                        style: TextStyle(
                          color: Colors.amberAccent,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 8),
                  
                  TextButton(
                    onPressed: () {
                      // Download invoice
                      _showDownloadOptions(context, orderId);
                    },
                    child: Text(
                      'Download Invoice',
                      style: TextStyle(
                        color: Colors.amberAccent,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPriceRow({
    required String label,
    required String value,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              color: Colors.grey.shade300,
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              color: Colors.amberAccent,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  IconData _getPaymentMethodIcon(String method) {
    switch (method.toLowerCase()) {
      case 'credit card':
        return Icons.credit_card;
      case 'paypal':
        return Icons.account_balance_wallet;
      case 'apple pay':
        return Icons.apple;
      case 'google pay':
        return Icons.phone_android;
      case 'cash on delivery':
        return Icons.money;
      default:
        return Icons.payment;
    }
  }

  double? _parseDouble(dynamic value) {
    if (value == null) return null;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value);
    return null;
  }

  int? _parseInt(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is String) return int.tryParse(value);
    return null;
  }

  void _showDownloadOptions(BuildContext context, String orderId) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.grey.shade900,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Download Invoice',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),
              ListTile(
                leading: Icon(Icons.picture_as_pdf, color: Colors.red),
                title: Text(
                  'Download as PDF',
                  style: TextStyle(color: Colors.white),
                ),
                subtitle: Text(
                  'Best for printing',
                  style: TextStyle(color: Colors.grey.shade400),
                ),
                onTap: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Downloading invoice for $orderId...'),
                      backgroundColor: Colors.green,
                    ),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.image, color: Colors.green),
                title: Text(
                  'Save as Image',
                  style: TextStyle(color: Colors.white),
                ),
                subtitle: Text(
                  'Share on social media',
                  style: TextStyle(color: Colors.grey.shade400),
                ),
                onTap: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Saving receipt as image...'),
                      backgroundColor: Colors.blue,
                    ),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.share, color: Colors.blue),
                title: Text(
                  'Share Receipt',
                  style: TextStyle(color: Colors.white),
                ),
                subtitle: Text(
                  'Share via email or message',
                  style: TextStyle(color: Colors.grey.shade400),
                ),
                onTap: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Sharing receipt...'),
                      backgroundColor: Colors.orange,
                    ),
                  );
                },
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(
                    'Cancel',
                    style: TextStyle(color: Colors.grey.shade400),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}