import 'package:flutter/material.dart';
import '../../data/repositories/cart_repository.dart';
import '../../data/repositories/address_repository.dart';
import '../../data/repositories/card_repository.dart';
import '../../data/models/cart_item_model.dart';
import '../../data/models/address_model.dart';
import '../../data/models/card_model.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final CartRepository _cartRepo = CartRepository();
  final AddressRepository _addressRepo = AddressRepository();
  final CardRepository _cardRepo = CardRepository();
  bool _expandedOrderInfo = false;
  Address? _primaryAddress;
  CardModel? _selectedCard;

  @override
  void initState() {
    super.initState();
    _loadPrimaryAddress();
    _loadSelectedCard();
  }

  // Load primary address
  Future<void> _loadPrimaryAddress() async {
    try {
      final address = await _addressRepo.getPrimaryAddress();
      if (address != null && mounted) {
        setState(() {
          _primaryAddress = address;
        });
      }
    } catch (e) {
      print('Error loading address: $e');
    }
  }

  // Load selected/default card
  Future<void> _loadSelectedCard() async {
    try {
      final card = await _cardRepo.getDefaultCard();
      if (card != null && mounted) {
        setState(() {
          _selectedCard = card;
        });
      }
    } catch (e) {
      print('Error loading card: $e');
    }
  }

  // Format address for display
  String _formatShortAddress(Address address) {
    if (address.addressLine2 != null && address.addressLine2!.isNotEmpty) {
      return '${address.addressLine1}, ${address.addressLine2}\n${address.city}, ${address.state} ${address.zipCode}';
    }
    return '${address.addressLine1}\n${address.city}, ${address.state} ${address.zipCode}';
  }

  // Get address display name with label
  String _getAddressDisplayName(Address address) {
    if (address.label.isNotEmpty && address.label != 'Home') {
      return '${address.label} • ${address.name}';
    }
    return address.name;
  }

  // Get card color based on type
  Color _getCardColor(String cardType) {
    switch (cardType.toLowerCase()) {
      case 'visa':
        return Colors.blue;
      case 'mastercard':
        return Colors.red;
      case 'amex':
        return Colors.green;
      case 'discover':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  double _calculateTotal(List<CartItem> items) {
    return items.fold(0, (sum, item) {
      final price = item.price ?? 0.0;
      return sum + price * item.quantity;
    });
  }

  void _showSnackBar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.grey.shade800,
        duration: const Duration(seconds: 1),
      ),
    );
  }

  @override
  void dispose() {
    _cartRepo.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Cart'),
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.more_vert, color: Colors.white),
            onPressed: () {
              showModalBottomSheet(
                context: context,
                backgroundColor: Colors.grey.shade900,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(20),
                  ),
                ),
                builder: (context) => Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ListTile(
                      leading: const Icon(Icons.edit, color: Colors.white),
                      title: const Text('Edit Cart', style: TextStyle(color: Colors.white)),
                      onTap: () {
                        Navigator.pop(context);
                        _showSnackBar(context, 'Edit feature coming soon!');
                      },
                    ),
                    ListTile(
                      leading: const Icon(Icons.delete, color: Colors.red),
                      title: const Text('Clear Cart', style: TextStyle(color: Colors.red)),
                      onTap: () {
                        Navigator.pop(context);
                        _cartRepo.clearCart().then((_) {
                          _showSnackBar(context, 'Cart cleared');
                        }).catchError((error) {
                          _showSnackBar(context, 'Failed to clear cart');
                        });
                      },
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
      body: StreamBuilder<List<CartItem>>(
        stream: _cartRepo.getCartItems(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(color: Colors.amberAccent),
            );
          }

          if (snapshot.hasError) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error, color: Colors.red, size: 50),
                  const SizedBox(height: 20),
                  Text(
                    'Error loading cart',
                    style: TextStyle(color: Colors.grey.shade400),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () => setState(() {}),
                    child: const Text('Retry'),
                  ),
                ],
              ),
            );
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.shopping_cart_outlined,
                    size: 80,
                    color: Colors.grey,
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'Your cart is empty',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Add some products to get started',
                    style: TextStyle(
                      color: Colors.grey.shade500,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pushReplacementNamed(context, '/home');
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.amberAccent,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 30,
                        vertical: 15,
                      ),
                    ),
                    child: const Text(
                      'Browse Products',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            );
          }

          final items = snapshot.data!;
          final subtotal = _calculateTotal(items);
          final shipping = 10.0;
          final total = subtotal + shipping;

          return Column(
            children: [
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(20),
                  children: [
                    // Cart Items
                    Column(
                      children: items.map((item) {
                        final itemPrice = item.price ?? 0.0;
                        return Container(
                          margin: const EdgeInsets.only(bottom: 16),
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade900,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Row(
                            children: [
                              // Product Image
                              Container(
                                width: 80,
                                height: 80,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(12),
                                  image: DecorationImage(
                                    image: NetworkImage(item.image),
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 16),
                              // Product Info
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      item.title,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16,
                                      ),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 8),
                                    if (item.size != null && item.size!.isNotEmpty)
                                      Text(
                                        'Size: ${item.size}',
                                        style: TextStyle(
                                          color: Colors.grey.shade400,
                                          fontSize: 14,
                                        ),
                                      ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '\$${itemPrice.toStringAsFixed(2)}',
                                      style: const TextStyle(
                                        color: Colors.amberAccent,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              // Quantity Controls
                              Column(
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                      color: Colors.grey.shade800,
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Row(
                                      children: [
                                        IconButton(
                                          icon: const Icon(Icons.remove, size: 20, color: Colors.white),
                                          onPressed: () {
                                            if (item.quantity > 1) {
                                              _cartRepo.updateQuantity(
                                                item.productId,
                                                item.quantity - 1,
                                                size: item.size,
                                              ).then((_) {
                                                _showSnackBar(context, 'Quantity decreased');
                                              }).catchError((error) {
                                                _showSnackBar(context, 'Failed to update quantity');
                                              });
                                            }
                                          },
                                        ),
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 12),
                                          child: Text(
                                            '${item.quantity}',
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 16,
                                            ),
                                          ),
                                        ),
                                        IconButton(
                                          icon: const Icon(Icons.add, size: 20, color: Colors.white),
                                          onPressed: () {
                                            _cartRepo.updateQuantity(
                                              item.productId,
                                              item.quantity + 1,
                                              size: item.size,
                                            ).then((_) {
                                              _showSnackBar(context, 'Quantity increased');
                                            }).catchError((error) {
                                              _showSnackBar(context, 'Failed to update quantity');
                                            });
                                          },
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  TextButton(
                                    onPressed: () {
                                      _cartRepo.removeFromCart(
                                        item.productId,
                                        size: item.size,
                                      ).then((_) {
                                        _showSnackBar(context, 'Item removed');
                                      }).catchError((error) {
                                        _showSnackBar(context, 'Failed to remove item');
                                      });
                                    },
                                    child: Text(
                                      'Remove',
                                      style: TextStyle(
                                        color: Colors.red.shade400,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),

                    const SizedBox(height: 24),

                    // Delivery Address Section
                    GestureDetector(
                      onTap: () async {
                        final result = await Navigator.pushNamed(context, '/address');
                        if (result == true) {
                          _loadPrimaryAddress();
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade900,
                          borderRadius: BorderRadius.circular(16),
                          border: _primaryAddress == null 
                              ? Border.all(color: Colors.amberAccent.withOpacity(0.3), width: 1)
                              : null,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.location_on_outlined,
                                        color: _primaryAddress == null 
                                            ? Colors.amberAccent 
                                            : Colors.grey.shade300,
                                        size: 20,
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        _primaryAddress == null 
                                            ? 'Add Delivery Address'
                                            : 'Delivery Address',
                                        style: TextStyle(
                                          color: _primaryAddress == null
                                              ? Colors.amberAccent
                                              : Colors.grey.shade300,
                                          fontSize: 14,
                                          fontWeight: _primaryAddress == null 
                                              ? FontWeight.w600 
                                              : FontWeight.normal,
                                        ),
                                      ),
                                      if (_primaryAddress != null && _primaryAddress!.isPrimary)
                                        Container(
                                          margin: const EdgeInsets.only(left: 8),
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 6,
                                            vertical: 2,
                                          ),
                                          decoration: BoxDecoration(
                                            color: Colors.amberAccent.withOpacity(0.2),
                                            borderRadius: BorderRadius.circular(4),
                                          ),
                                          child: Text(
                                            'PRIMARY',
                                            style: TextStyle(
                                              color: Colors.amberAccent,
                                              fontSize: 10,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  if (_primaryAddress != null)
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          _getAddressDisplayName(_primaryAddress!),
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          _formatShortAddress(_primaryAddress!),
                                          style: TextStyle(
                                            color: Colors.grey.shade400,
                                            fontSize: 14,
                                          ),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          _primaryAddress!.phone,
                                          style: TextStyle(
                                            color: Colors.grey.shade500,
                                            fontSize: 13,
                                          ),
                                        ),
                                      ],
                                    )
                                  else
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'No address saved',
                                          style: TextStyle(
                                            color: Colors.grey.shade400,
                                            fontSize: 16,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          'Required for checkout',
                                          style: TextStyle(
                                            color: Colors.amberAccent.shade200,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ],
                                    ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            Icon(
                              Icons.chevron_right,
                              color: _primaryAddress == null 
                                  ? Colors.amberAccent 
                                  : Colors.grey,
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Payment Method Section
                    GestureDetector(
                      onTap: () async {
                        final result = await Navigator.pushNamed(context, '/payment-methods');
                        if (result == true) {
                          _loadSelectedCard();
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade900,
                          borderRadius: BorderRadius.circular(16),
                          border: _selectedCard == null 
                              ? Border.all(color: Colors.blue.withOpacity(0.3), width: 1)
                              : null,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: _getCardColor(_selectedCard?.cardType ?? ''),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Icon(
                                    _selectedCard != null 
                                        ? Icons.credit_card 
                                        : Icons.add_card,
                                    color: Colors.white,
                                    size: 24,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Payment Method',
                                      style: TextStyle(
                                        color: Colors.grey.shade300,
                                        fontSize: 14,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      _selectedCard?.fullMaskedCardNumber ?? 'Add Payment Method',
                                      style: TextStyle(
                                        color: _selectedCard == null
                                            ? Colors.blue.shade300
                                            : Colors.white,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Icon(
                              Icons.chevron_right,
                              color: _selectedCard == null 
                                  ? Colors.blue 
                                  : Colors.grey,
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Order Info Section
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _expandedOrderInfo = !_expandedOrderInfo;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade900,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Order Info',
                                  style: TextStyle(
                                    color: Colors.grey.shade300,
                                    fontSize: 14,
                                  ),
                                ),
                                Icon(
                                  _expandedOrderInfo
                                      ? Icons.expand_less
                                      : Icons.expand_more,
                                  color: Colors.grey,
                                ),
                              ],
                            ),
                            if (_expandedOrderInfo) ...[
                              const SizedBox(height: 16),
                              _buildOrderInfoRow('Subtotal', subtotal),
                              const SizedBox(height: 8),
                              _buildOrderInfoRow('Shipping cost', shipping),
                              const SizedBox(height: 12),
                              const Divider(color: Colors.grey),
                              const SizedBox(height: 12),
                              _buildOrderInfoRow('Total', total, isTotal: true),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Checkout Button - FIXED: Navigate to /checkout instead of /order-confirmed
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.grey.shade900,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(20),
                  ),
                ),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      // Check both address and payment method
                      final hasAddress = await _addressRepo.validateCheckoutAddress();
                      final hasCard = await _cardRepo.hasCards();
                      
                      if (!hasAddress || !hasCard) {
                        String missingItems = '';
                        if (!hasAddress) missingItems += 'delivery address';
                        if (!hasCard) {
                          if (missingItems.isNotEmpty) missingItems += ' and ';
                          missingItems += 'payment method';
                        }
                        
                        showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                            backgroundColor: Colors.grey.shade900,
                            title: const Text(
                              'Checkout Requirements',
                              style: TextStyle(color: Colors.white),
                            ),
                            content: Text(
                              'You need to add a $missingItems before checkout.',
                              style: TextStyle(color: Colors.grey.shade300),
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context),
                                child: const Text(
                                  'Cancel',
                                  style: TextStyle(color: Colors.grey),
                                ),
                              ),
                              TextButton(
                                onPressed: () async {
                                  Navigator.pop(context);
                                  if (!hasAddress) {
                                    final result = await Navigator.pushNamed(context, '/address');
                                    if (result == true) {
                                      _loadPrimaryAddress();
                                    }
                                  } else if (!hasCard) {
                                    final result = await Navigator.pushNamed(context, '/payment-methods');
                                    if (result == true) {
                                      _loadSelectedCard();
                                    }
                                  }
                                },
                                child: Text(
                                  !hasAddress ? 'Add Address' : 'Add Payment Method',
                                  style: const TextStyle(color: Colors.amberAccent),
                                ),
                              ),
                            ],
                          ),
                        );
                      } else {
                        // CORRECT: Navigate to /checkout to review order
                        Navigator.pushNamed(
                          context,
                          '/checkout',
                          arguments: items, // Just pass the cart items
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: (_primaryAddress == null || _selectedCard == null)
                          ? Colors.grey.shade700 
                          : Colors.amberAccent,
                      foregroundColor: (_primaryAddress == null || _selectedCard == null)
                          ? Colors.grey.shade400 
                          : Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      elevation: 4,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.shopping_bag_outlined, size: 20),
                        const SizedBox(width: 10),
                        Text(
                          (_primaryAddress == null && _selectedCard == null)
                              ? 'Add Address & Payment'
                              : _primaryAddress == null
                                  ? 'Add Address to Checkout'
                                  : _selectedCard == null
                                      ? 'Add Payment Method'
                                      : 'Checkout \$${total.toStringAsFixed(2)}',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildOrderInfoRow(String label, double amount, {bool isTotal = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            color: Colors.grey.shade300,
            fontSize: isTotal ? 16 : 14,
          ),
        ),
        Text(
          '\$${amount.toStringAsFixed(2)}',
          style: TextStyle(
            color: isTotal ? Colors.amberAccent : Colors.white,
            fontSize: isTotal ? 18 : 16,
            fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ],
    );
  }
}