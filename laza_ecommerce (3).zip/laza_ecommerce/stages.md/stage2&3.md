Laza E-commerce Flutter Project
Stage 2: Create Flutter Project
Overview

Stage 2 focuses on creating a Flutter project and verifying that the default app runs correctly on an Android Emulator.

Step 1: Create Flutter Project
flutter create laza_ecommerce


This generates the base Flutter project structure.

Step 2: Open Project in IDE

Android Studio

Open Android Studio → Open an existing project

Navigate to your project folder (laza_ecommerce) → OK

Wait for indexing and Gradle sync to finish

VS Code

Open VS Code → File → Open Folder → Select laza_ecommerce

Open terminal → run:

flutter pub get

Step 3: Run Project on Emulator

Launch your Android Emulator from AVD Manager

Run the Flutter app:

flutter run -d emulator-5554

Step 4: Confirm Default App Works

Check that the default Flutter demo app or your main.dart runs correctly on the Emulator

Screen should display "Flutter Demo Home Page" or your demo UI

Stage 2 Checklist
Task	Status
Create Flutter project	✅ Done
Open project in IDE	⬜ Pending
Run project on Emulator	⬜ Pending
Confirm default app works	⬜ Pending
Stage 3: Project Structure
Overview

Stage 3 focuses on organizing the project structure following MVVM-like architecture for scalability, maintainability, and clean separation of concerns.

Folder Structure
lib/
├── main.dart
├── core/
│   ├── constants/
│   ├── services/
│   ├── utils/
│   └── widgets/
├── data/
│   ├── models/
│   ├── repositories/
│   └── datasources/
├── domain/
│   └── entities/
├── presentation/
│   ├── screens/
│   ├── widgets/
│   └── providers/
└── routes/

Folder Purpose
Folder	Purpose
core/constants	App-wide constants (colors, strings, keys)
core/services	Reusable services (API, Firebase, Auth, etc.)
core/utils	Helper functions and utilities
core/widgets	Reusable widgets (buttons, cards, etc.)
data/models	Data models (Product, User, etc.)
data/repositories	Data repositories handling data sources
data/datasources	API or local database handlers
domain/entities	Core business entities
presentation/screens	Screens / Views (UI)
presentation/widgets	Screen-specific widgets
presentation/providers	State management / ViewModels
routes	App navigation and routing logic
MVVM Alignment

Model → data/models/

View → presentation/screens/

ViewModel / Provider → presentation/providers/

Repository → data/repositories/

Services → core/services/

Widgets / Utils → reusable UI components and helper functions